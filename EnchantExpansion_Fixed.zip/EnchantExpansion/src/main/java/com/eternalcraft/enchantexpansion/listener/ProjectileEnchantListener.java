package com.eternalcraft.enchantexpansion.listener;

import com.eternalcraft.enchantexpansion.EnchantExpansionPlugin;
import com.eternalcraft.enchantexpansion.manager.EnchantManager;
import org.bukkit.*;
import org.bukkit.entity.*;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityShootBowEvent;
import org.bukkit.event.entity.ProjectileHitEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.metadata.FixedMetadataValue;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.Vector;

import java.util.*;

public class ProjectileEnchantListener implements Listener {

    private final EnchantExpansionPlugin plugin;
    private final EnchantManager em;
    private final Random random = new Random();

    // Track homing arrows
    private final Map<UUID, BukkitTask> homingTasks = new HashMap<>();
    // Track arrow rain active state per player
    private final Map<UUID, Boolean> arrowRainHold = new HashMap<>();

    // Passive mob types
    private static final Set<EntityType> PASSIVE_MOBS = Set.of(
            EntityType.COW, EntityType.SHEEP, EntityType.PIG, EntityType.CHICKEN,
            EntityType.RABBIT, EntityType.HORSE, EntityType.DONKEY, EntityType.MULE,
            EntityType.LLAMA, EntityType.COD, EntityType.SALMON, EntityType.TROPICAL_FISH,
            EntityType.PUFFERFISH, EntityType.SQUID, EntityType.GLOW_SQUID,
            EntityType.MOOSHROOM, EntityType.SNOW_GOLEM, EntityType.BAT,
            EntityType.FOX, EntityType.OCELOT, EntityType.PARROT, EntityType.STRIDER,
            EntityType.TURTLE, EntityType.WANDERING_TRADER, EntityType.VILLAGER,
            EntityType.CAT, EntityType.AXOLOTL, EntityType.FROG, EntityType.TADPOLE,
            EntityType.CAMEL, EntityType.SNIFFER, EntityType.ALLAY);

    // Water / aquatic mob types
    private static final Set<EntityType> WATER_MOBS = Set.of(
            EntityType.DROWNED, EntityType.GUARDIAN, EntityType.ELDER_GUARDIAN,
            EntityType.COD, EntityType.SALMON, EntityType.SQUID, EntityType.GLOW_SQUID,
            EntityType.PUFFERFISH, EntityType.TROPICAL_FISH, EntityType.TURTLE, EntityType.AXOLOTL);

    public ProjectileEnchantListener(EnchantExpansionPlugin plugin, EnchantManager em) {
        this.plugin = plugin;
        this.em = em;
    }

    // ======================== SHOOT BOW EVENT ========================

    @EventHandler
    public void onBowShoot(EntityShootBowEvent event) {
        if (!(event.getEntity() instanceof Player player)) return;
        ItemStack bow = event.getBow();
        if (bow == null) return;

        Projectile proj = (event.getProjectile() instanceof Projectile p) ? p : null;
        if (proj == null) return;

        // Super Arrow: faster velocity
        if (em.hasEnchant(bow, "super_arrow")) {
            Vector v = proj.getVelocity();
            proj.setVelocity(v.multiply(1.8));
            proj.setMetadata("super_arrow", new FixedMetadataValue(plugin, true));
        }

        // Tag the projectile with all bow enchants so we can react on hit
        tagProjectile(proj, player, bow);

        // Homing: start tracking task
        if (em.hasEnchant(bow, "homing") && proj instanceof Arrow arrow) {
            startHomingTask(player, arrow);
        }

        // Fire Ball (crossbow only): replace with small fireball
        if (em.hasEnchant(bow, "fire_ball") && bow.getType() == Material.CROSSBOW) {
            event.setCancelled(true);
            SmallFireball fireball = (SmallFireball) player.getWorld().spawnEntity(
                    player.getEyeLocation(), EntityType.SMALL_FIREBALL);
            fireball.setShooter(player);
            fireball.setDirection(player.getEyeLocation().getDirection().multiply(2));
            fireball.setMetadata("ce_fireball", new FixedMetadataValue(plugin, true));
            fireball.setMetadata("shooter", new FixedMetadataValue(plugin, player.getUniqueId().toString()));
            player.getWorld().playSound(player.getLocation(), Sound.ENTITY_GHAST_SHOOT, 0.7f, 1.5f);
        }
    }

    private void tagProjectile(Projectile proj, Player player, ItemStack bow) {
        String[] tags = {"hunter","frost_arrow","extra_power","poison_arrows","lightning_arrow",
                "explosion_arrow","guardian_arrow","homing","arrow_rain"};
        for (String tag : tags) {
            if (em.hasEnchant(bow, tag)) {
                proj.setMetadata("ce_" + tag, new FixedMetadataValue(plugin, true));
            }
        }
        proj.setMetadata("ce_shooter", new FixedMetadataValue(plugin, player.getUniqueId().toString()));
    }

    // ======================== PROJECTILE HIT EVENT ========================

    @EventHandler(priority = EventPriority.HIGH)
    public void onProjectileHit(ProjectileHitEvent event) {
        Projectile proj = event.getEntity();
        if (!(proj.getShooter() instanceof Player player)) return;

        Entity hitEntity = event.getHitEntity();
        boolean hitMob = hitEntity instanceof LivingEntity && !(hitEntity instanceof Player p && p == player);

        // Frost Arrow: Slowness on hit
        if (hasMeta(proj, "ce_frost_arrow") && hitMob) {
            ((LivingEntity) hitEntity).addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS, 60, 0, true, true));
        }

        // Poison Arrows: Poison on hit
        if (hasMeta(proj, "ce_poison_arrows") && hitMob) {
            ((LivingEntity) hitEntity).addPotionEffect(new PotionEffect(PotionEffectType.POISON, 60, 0, true, true));
        }

        // Lightning Arrow: strike lightning
        if (hasMeta(proj, "ce_lightning_arrow")) {
            Location loc = hitEntity != null ? hitEntity.getLocation() : event.getHitBlock() != null
                    ? event.getHitBlock().getLocation() : null;
            if (loc != null) {
                proj.getWorld().strikeLightningEffect(loc);
                if (hitMob) ((LivingEntity) hitEntity).damage(3.0, player);
            }
        }

        // Explosion Arrow: area explosion (no block damage)
        if (hasMeta(proj, "ce_explosion_arrow")) {
            Location loc = proj.getLocation();
            proj.getWorld().spawnParticle(Particle.EXPLOSION, loc, 5, 0.5, 0.5, 0.5);
            proj.getWorld().playSound(loc, Sound.ENTITY_GENERIC_EXPLODE, 1f, 1.5f);
            for (LivingEntity nearby : loc.getNearbyLivingEntities(3)) {
                if (nearby == player) continue;
                double dist = nearby.getLocation().distance(loc);
                double dmg = 8 * (1 - dist / 3.0);
                nearby.damage(Math.max(2, dmg), player);
            }
        }

        // Guardian Arrow: handled in damage event for armor piercing
        // Hunter/Extra Power: handled in damage event
    }

    // ======================== DAMAGE FROM PROJECTILE ========================

    @EventHandler(priority = EventPriority.NORMAL)
    public void onArrowDamage(EntityDamageByEntityEvent event) {
        if (!(event.getEntity() instanceof LivingEntity target)) return;

        // Arrow damage
        if (event.getDamager() instanceof Arrow arrow) {
            if (!(arrow.getShooter() instanceof Player player)) return;

            double dmg = event.getDamage();
            EntityType targetType = target.getType();

            // Hunter: +40% to passive mobs
            if (hasMeta(arrow, "ce_hunter") && PASSIVE_MOBS.contains(targetType)) {
                dmg *= 1.40;
                event.setDamage(dmg);
            }

            // Extra Power: flat +3 damage
            if (hasMeta(arrow, "ce_extra_power")) {
                dmg += 3.0;
                event.setDamage(dmg);
            }

            // Guardian Arrow: 30% armor pierce + 2.5x to water mobs
            if (hasMeta(arrow, "ce_guardian_arrow")) {
                if (WATER_MOBS.contains(targetType)) {
                    dmg *= 2.5;
                }
                // Armor piercing: +25% extra damage to simulate
                dmg *= 1.30;
                event.setDamage(dmg);
            }
        }

        // Trident damage
        if (event.getDamager() instanceof Trident trident) {
            if (!(trident.getShooter() instanceof Player player)) return;
            ItemStack tridentItem = player.getInventory().getItemInMainHand();
            if (tridentItem.getType() != Material.TRIDENT) return;

            // Poseidon: +4 damage bonus
            if (em.hasEnchant(tridentItem, "poseidon")) {
                event.setDamage(event.getDamage() + 4.0);
                target.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS, 40, 0));
            }

            // Water Explosion
            if (em.hasEnchant(tridentItem, "water_explosion")) {
                Location loc = target.getLocation();
                // Water explosion: push effect
                for (LivingEntity nearby : loc.getNearbyLivingEntities(5)) {
                    if (nearby == player) continue;
                    Vector away = nearby.getLocation().subtract(loc).toVector().normalize().multiply(2.5);
                    away.setY(1.0);
                    nearby.setVelocity(away);
                    nearby.damage(4.0, player);
                }
                // Particles: water splash
                player.getWorld().spawnParticle(Particle.SPLASH, loc, 100, 3, 1, 3, 0.2);
                player.getWorld().spawnParticle(Particle.BUBBLE_COLUMN_UP, loc, 50, 2, 1, 2, 0.1);
                player.getWorld().playSound(loc, Sound.ENTITY_GENERIC_SPLASH, 2f, 0.7f);
                player.getWorld().playSound(loc, Sound.ENTITY_GENERIC_EXPLODE, 0.8f, 1.5f);
                player.sendMessage("§9Water Explosion §7meledak!");
            }
        }
    }

    // ======================== HOMING ARROW ========================

    private void startHomingTask(Player player, Arrow arrow) {
        BukkitTask task = new BukkitRunnable() {
            int ticks = 0;
            @Override
            public void run() {
                ticks++;
                if (ticks > 60 || !arrow.isValid() || arrow.isOnGround()) { cancel(); return; }

                // Find nearest living entity
                LivingEntity target = null;
                double minDist = 30;
                for (Entity e : arrow.getNearbyEntities(20, 20, 20)) {
                    if (!(e instanceof LivingEntity le) || e == player) continue;
                    double d = e.getLocation().distanceSquared(arrow.getLocation());
                    if (d < minDist * minDist) { minDist = d; target = le; }
                }

                if (target == null) return;

                Vector dir = target.getEyeLocation().subtract(arrow.getLocation()).toVector().normalize();
                Vector current = arrow.getVelocity();
                // Lerp towards target
                Vector newVel = current.multiply(0.8).add(dir.multiply(current.length() * 0.3));
                arrow.setVelocity(newVel);
                arrow.getWorld().spawnParticle(Particle.CRIT_MAGIC, arrow.getLocation(), 2, 0.1, 0.1, 0.1);
            }
        }.runTaskTimer(plugin, 0L, 1L);
        homingTasks.put(arrow.getUniqueId(), task);
    }

    // ======================== ARROW RAIN (Active skill) ========================
    // Arrow rain is triggered from ActiveSkillListener via SNEAK+HOLD key,
    // but we handle the actual rain logic here

    public void activateArrowRain(Player player, boolean hasExplosion) {
        Location loc = player.getLocation();
        player.sendMessage("§6Arrow Rain §7— Hujan panah dari langit!");
        player.playSound(loc, Sound.ENTITY_ARROW_SHOOT, 1f, 0.5f);

        new BukkitRunnable() {
            int count = 0;
            @Override
            public void run() {
                count++;
                if (count > 20 || !player.isOnline()) { cancel(); return; }

                // Spawn arrow from above at random offset
                double x = (random.nextDouble() - 0.5) * 16;
                double z = (random.nextDouble() - 0.5) * 16;
                Location spawnLoc = loc.clone().add(x, 25, z);

                Arrow arrow = player.getWorld().spawnArrow(spawnLoc, new Vector(0, -1, 0), 2f, 0f);
                arrow.setShooter(player);

                if (hasExplosion) {
                    arrow.setMetadata("ce_explosion_arrow", new FixedMetadataValue(plugin, true));
                }

                player.getWorld().spawnParticle(Particle.CRIT, spawnLoc, 3, 0.3, 0, 0.3);
            }
        }.runTaskTimer(plugin, 0L, 3L);
    }

    // ======================== DEMONIC TAKAZ AURA ========================

    public void tickDemonicTakazAura(Player player) {
        Location loc = player.getLocation().add(0, 1, 0);

        // Blue-red fire particles
        double angle = (plugin.getServer().getCurrentTick() % 36) * 10 * Math.PI / 180;
        for (int i = 0; i < 3; i++) {
            double a = angle + i * (2 * Math.PI / 3);
            Location ring = loc.clone().add(Math.cos(a) * 1.2, 0, Math.sin(a) * 1.2);
            player.getWorld().spawnParticle(Particle.SOUL_FIRE_FLAME, ring, 2, 0.1, 0.2, 0.1, 0.01);
            player.getWorld().spawnParticle(Particle.FLAME, ring.clone().add(0, 0.3, 0), 1, 0.1, 0.1, 0.1, 0.01);
        }
        player.getWorld().spawnParticle(Particle.SOUL, loc, 2, 0.4, 0.2, 0.4, 0.01);

        // Passive: Fire Resistance + Resistance I
        int dur = 60;
        player.addPotionEffect(new PotionEffect(PotionEffectType.FIRE_RESISTANCE, dur, 0, true, false, false));
        player.addPotionEffect(new PotionEffect(PotionEffectType.RESISTANCE, dur, 0, true, false, false));

        // Damage nearby mobs
        for (LivingEntity nearby : loc.getNearbyLivingEntities(2.5)) {
            if (nearby == player) continue;
            nearby.addPotionEffect(new PotionEffect(PotionEffectType.WITHER, 40, 0, true, false));
            nearby.setFireTicks(40);
        }
    }

    public void activateDemonicBurst(Player player) {
        player.sendMessage("§4§lDEMONIC BURST §7— Ledakan api biru-merah!");
        player.playSound(player.getLocation(), Sound.ENTITY_WITHER_DEATH, 0.8f, 1.5f);
        player.playSound(player.getLocation(), Sound.ENTITY_BLAZE_SHOOT, 1f, 0.5f);

        Location loc = player.getLocation().add(0, 1, 0);

        // Soul fire blue + red flame particles burst
        player.getWorld().spawnParticle(Particle.SOUL_FIRE_FLAME, loc, 80, 3, 1, 3, 0.2);
        player.getWorld().spawnParticle(Particle.FLAME, loc, 60, 3, 1, 3, 0.3);
        player.getWorld().spawnParticle(Particle.LAVA, loc, 30, 2, 1, 2);
        player.getWorld().spawnParticle(Particle.EXPLOSION, loc, 5, 1, 0.5, 1);

        // Damage all nearby entities
        for (LivingEntity nearby : loc.getNearbyLivingEntities(6)) {
            if (nearby == player) continue;
            double dist = nearby.getLocation().distance(loc);
            double dmg = 10 * (1 - dist / 6.0);
            nearby.damage(Math.max(4, dmg), player);
            nearby.setFireTicks(100); // 5 seconds
            nearby.addPotionEffect(new PotionEffect(PotionEffectType.WITHER, 60, 0));
            nearby.setVelocity(nearby.getLocation().subtract(loc).toVector().normalize().multiply(2).add(new Vector(0, 0.5, 0)));
        }
    }

    // ======================== SECRET REWORK PASSIVES ========================

    public void tickWitherStormPassive(Player player) {
        Location loc = player.getLocation().add(0, 1, 0);
        int dur = 60;

        // Soul Armor: handled in damage event (35% reduction)
        // Boss Health: +20 HP = handled in heart_of_titan style tick in PassiveEnchantListener

        // Wither Aura (5 block radius)
        for (LivingEntity nearby : loc.getNearbyLivingEntities(5)) {
            if (nearby == player) continue;
            nearby.addPotionEffect(new PotionEffect(PotionEffectType.WITHER, 40, 1, true, false));
        }

        // Particles: large dark aura
        for (int i = 0; i < 5; i++) {
            double a = random.nextDouble() * 2 * Math.PI;
            double r = 2 + random.nextDouble() * 3;
            Location p2 = loc.clone().add(Math.cos(a) * r, random.nextDouble() * 2, Math.sin(a) * r);
            player.getWorld().spawnParticle(Particle.SOUL, p2, 1, 0.1, 0.1, 0.1, 0.01);
            player.getWorld().spawnParticle(Particle.SMOKE, p2, 1, 0, 0, 0, 0.01);
        }
        player.getWorld().spawnParticle(Particle.WITCH, loc, 5, 0.5, 0.5, 0.5, 0);
    }

    public void tickHerobrinePassive(Player player) {
        Location loc = player.getLocation().add(0, 1, 0);
        int dur = 60;

        // A Myth: dark aura particles
        player.getWorld().spawnParticle(Particle.SOUL, loc, 3, 0.5, 0.5, 0.5, 0.02);
        player.getWorld().spawnParticle(Particle.SMOKE, loc, 5, 0.3, 0.5, 0.3, 0.03);

        // Sprint: Invisible + Blindness to nearby
        if (player.isSprinting()) {
            player.addPotionEffect(new PotionEffect(PotionEffectType.INVISIBILITY, dur, 0, true, false, false));
            for (LivingEntity nearby : loc.getNearbyLivingEntities(5)) {
                if (nearby == player) continue;
                nearby.addPotionEffect(new PotionEffect(PotionEffectType.BLINDNESS, 60, 0, true, false));
            }
        }

        // Blindness fog radius 50 blocks (applied visually via Darkness effect range)
        for (Player other : player.getWorld().getNearbyPlayers(loc, 50)) {
            if (other == player) continue;
            other.addPotionEffect(new PotionEffect(PotionEffectType.DARKNESS, 80, 0, true, false, false));
        }
    }

    // ======================== HEROBRINE TELEPORTATION ========================

    public void activateHerobrineTeleport(Player player) {
        Location loc = player.getLocation();

        // Wither 2 to all nearby before teleport
        for (LivingEntity nearby : loc.getNearbyLivingEntities(10)) {
            if (nearby == player) continue;
            nearby.addPotionEffect(new PotionEffect(PotionEffectType.WITHER, 100, 1, true, true));
        }

        // Effect before
        player.getWorld().spawnParticle(Particle.SOUL, loc.add(0, 1, 0), 50, 2, 1, 2, 0.05);
        player.playSound(loc, Sound.ENTITY_ENDERMAN_TELEPORT, 1f, 0.5f);

        // Teleport random 60 block radius
        double angle = random.nextDouble() * 2 * Math.PI;
        double dist = 30 + random.nextDouble() * 30;
        Location newLoc = loc.clone().add(Math.cos(angle) * dist, 0, Math.sin(angle) * dist);
        // Find safe Y
        newLoc = player.getWorld().getHighestBlockAt(newLoc).getLocation().add(0, 1, 0);

        player.teleport(newLoc);
        player.getWorld().spawnParticle(Particle.SOUL, newLoc.add(0, 1, 0), 30, 1, 1, 1, 0.05);
        player.playSound(newLoc, Sound.ENTITY_ENDERMAN_TELEPORT, 1f, 1.5f);
        player.sendMessage("§8Teleportation §7— Kamu menghilang ke dalam kegelapan...");
    }

    // ======================== WITHER STORM LASER ========================

    public void activateWitherStormLaser(Player player) {
        player.sendMessage("§5§lWITHER STORM LASER §7— Menarik semua entitas!");
        player.playSound(player.getLocation(), Sound.ENTITY_GUARDIAN_ELDER_HURT, 1f, 0.3f);
        player.playSound(player.getLocation(), Sound.ENTITY_WITHER_AMBIENT, 1f, 0.5f);

        new BukkitRunnable() {
            int ticks = 0;
            @Override
            public void run() {
                ticks++;
                if (ticks > 60 || !player.isOnline()) { cancel(); return; }

                Location eyeLoc = player.getEyeLocation();
                Vector dir = eyeLoc.getDirection().normalize();

                // Draw laser line
                for (int i = 1; i <= 30; i++) {
                    Location point = eyeLoc.clone().add(dir.clone().multiply(i * 0.5));
                    player.getWorld().spawnParticle(Particle.DRAGON_BREATH, point, 3, 0.2, 0.2, 0.2, 0.01);
                    player.getWorld().spawnParticle(Particle.WITCH, point, 1);

                    if (point.getBlock().getType().isSolid()) break;

                    // Attract + damage nearby entities
                    for (LivingEntity e : point.getNearbyLivingEntities(2)) {
                        if (e == player) continue;
                        // Pull towards player
                        Vector pull = player.getLocation().add(0, 1, 0).subtract(e.getLocation()).toVector();
                        double dist = pull.length();
                        double damage = Math.max(1, 30 - dist * 2); // semakin dekat semakin besar
                        e.damage(damage * 0.05, player); // per tick
                        e.setVelocity(pull.normalize().multiply(0.5));
                    }
                }
            }
        }.runTaskTimer(plugin, 0L, 1L);
    }

    // ======================== HELPER ========================

    private boolean hasMeta(Entity e, String key) {
        return e.hasMetadata(key);
    }
}
