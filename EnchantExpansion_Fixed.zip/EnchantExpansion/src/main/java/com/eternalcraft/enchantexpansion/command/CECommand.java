package com.eternalcraft.enchantexpansion.command;

import com.eternalcraft.enchantexpansion.EnchantExpansionPlugin;
import com.eternalcraft.enchantexpansion.gui.AdminGUI;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

import java.util.List;

public class CECommand implements CommandExecutor, TabCompleter {

    private final EnchantExpansionPlugin plugin;

    public CECommand(EnchantExpansionPlugin plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage("§cHanya player yang bisa menggunakan command ini.");
            return true;
        }

        if (!player.hasPermission("enchantexpansion.admin")) {
            player.sendMessage(plugin.getConfig().getString("messages.prefix") + "§cKamu tidak punya izin!");
            return true;
        }

        // /ce  or  /ce give  ->  open admin menu
        AdminGUI adminGUI = new AdminGUI(plugin, AdminGUI.AdminGUIType.MAIN);
        player.openInventory(adminGUI.getInventory());
        player.sendMessage("§a[ADMIN] Menu CE dibuka.");
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command cmd, String alias, String[] args) {
        return List.of();
    }
}
