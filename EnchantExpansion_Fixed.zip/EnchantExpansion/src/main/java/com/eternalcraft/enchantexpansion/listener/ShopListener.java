package com.eternalcraft.enchantexpansion.listener;

import com.eternalcraft.enchantexpansion.EnchantExpansionPlugin;
import com.eternalcraft.enchantexpansion.data.CustomEnchantData;
import com.eternalcraft.enchantexpansion.enums.EnchantTier;
import com.eternalcraft.enchantexpansion.gui.AdminGUI;
import com.eternalcraft.enchantexpansion.gui.ShopGUI;
import com.eternalcraft.enchantexpansion.manager.EnchantManager;
import com.eternalcraft.enchantexpansion.manager.GachaManager;
import com.eternalcraft.enchantexpansion.manager.RitualManager;
import com.eternalcraft.enchantexpansion.registry.EnchantRegistry;
import com.eternalcraft.enchantexpansion.util.ItemUtil;
import com.eternalcraft.enchantexpansion.util.PDCUtil;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.entity.Villager;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.player.PlayerInteractEntityEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;

public class ShopListener implements Listener {

    private final EnchantExpansionPlugin plugin;
    private final GachaManager gachaManager;
    private final EnchantManager enchantManager;

    public ShopListener(EnchantExpansionPlugin plugin, GachaManager gachaManager, EnchantManager enchantManager) {
        this.plugin = plugin;
        this.gachaManager = gachaManager;
        this.enchantManager = enchantManager;
    }

    // Open shop on villager right-click
    @EventHandler
    public void onVillagerClick(PlayerInteractEntityEvent event) {
        if (!(event.getRightClicked() instanceof Villager villager)) return;
        if (!PDCUtil.isShopVillager(villager)) return;

        event.setCancelled(true);
        ShopGUI gui = new ShopGUI(plugin);
        event.getPlayer().openInventory(gui.getInventory());
    }

    // Shop GUI click
    @EventHandler
    public void onShopClick(InventoryClickEvent event) {
        if (!(event.getWhoClicked() instanceof Player player)) return;
        Inventory topInv = event.getView().getTopInventory();

        // Shop GUI
        if (topInv.getHolder() instanceof ShopGUI) {
            event.setCancelled(true);
            EnchantTier tier = ShopGUI.getTierFromSlot(event.getRawSlot());
            if (tier == null) return;

            // Give gacha item (deduct XP at opening time)
            int xpCost = tier.getXpPrice();
            if (player.getTotalExperience() < xpCost) {
                player.sendMessage("§cXP tidak cukup! Butuh §e" + xpCost + " XP.");
                player.playSound(player.getLocation(), Sound.ENTITY_VILLAGER_NO, 1f, 1f);
                return;
            }

            // Give gacha item to player
            ItemStack gacha = ItemUtil.createGachaItem(tier);
            player.closeInventory();
            player.getInventory().addItem(gacha);
            player.sendMessage("§aKamu mendapatkan §eGacha " + tier.getDisplayName() + "§a! Klik item untuk membuka.");
            player.playSound(player.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, 1f, 1.5f);

            // Deduct XP
            int totalXp = player.getTotalExperience();
            player.setTotalExperience(Math.max(0, totalXp - xpCost));
            return;
        }

        // Admin GUI (Main)
        if (topInv.getHolder() instanceof AdminGUI adminGUI) {
            event.setCancelled(true);

            if (event.getRawSlot() >= topInv.getSize()) return; // Bottom inventory

            // Gacha slots 0-6
            if (AdminGUI.isGachaSlot(event.getRawSlot())) {
                ItemStack clicked = event.getCurrentItem();
                if (clicked == null || PDCUtil.getGachaTier(clicked) == null) return;
                ItemStack toGive = clicked.clone();
                toGive.setAmount(1);
                player.getInventory().addItem(toGive);
                player.sendMessage("§a[ADMIN] Item diberikan!");
                player.playSound(player.getLocation(), Sound.ENTITY_ITEM_PICKUP, 1f, 2f);
                return;
            }

            // Open enchant list
            if (AdminGUI.isEnchantBookButton(event.getRawSlot())) {
                AdminGUI enchantGui = new AdminGUI(plugin, AdminGUI.AdminGUIType.ENCHANT_LIST);
                player.openInventory(enchantGui.getInventory());
                return;
            }

            // Spawn shop villager
            if (AdminGUI.isVillagerSpawnButton(event.getRawSlot())) {
                Villager v = player.getWorld().spawn(player.getLocation().add(1, 0, 0), Villager.class);
                v.setCustomName(plugin.getConfig().getString("shop-villager-name", "§6✦ Enchant Gacha Shop ✦"));
                v.setCustomNameVisible(true);
                v.setInvulnerable(true);
                v.setAI(false);
                v.setGravity(false);
                PDCUtil.markShopVillager(v);
                player.sendMessage("§a[ADMIN] Shop villager di-spawn!");
                player.closeInventory();
                return;
            }

            return;
        }

        // Admin GUI (Enchant List)
        if (event.getView().getTitle().equals(AdminGUI.ENCHANT_TITLE)) {
            event.setCancelled(true);
            if (event.getRawSlot() >= topInv.getSize()) return;
            ItemStack clicked = event.getCurrentItem();
            if (clicked == null) return;
            String enchantId = PDCUtil.getEnchantBookId(clicked);
            if (enchantId == null) return;
            ItemStack book = ItemUtil.createEnchantBook(EnchantRegistry.get(enchantId));
            player.getInventory().addItem(book);
            player.sendMessage("§a[ADMIN] Enchant book diberikan: §e" + enchantId);
        }
    }

    // Handle dragging enchant book onto item (in player inventory)
    @EventHandler
    public void onEnchantApply(InventoryClickEvent event) {
        if (!(event.getWhoClicked() instanceof Player player)) return;

        // Check if cursor is enchant book
        ItemStack cursor = event.getCursor();
        if (cursor == null || cursor.getType() == org.bukkit.Material.AIR) return;

        String enchantId = PDCUtil.getEnchantBookId(cursor);
        if (enchantId == null) return;

        // Check if clicking on an item in player inventory
        ItemStack target = event.getCurrentItem();
        if (target == null || target.getType() == org.bukkit.Material.AIR) return;

        // Prevent default behavior
        event.setCancelled(true);

        CustomEnchantData enchant = EnchantRegistry.get(enchantId);
        if (enchant == null) { player.sendMessage("§cEnchant tidak ditemukan!"); return; }

        EnchantManager.ApplyResult result = enchantManager.tryApply(target, enchantId, player);
        String prefix = plugin.getConfig().getString("messages.prefix", "§8[§6CE§8] ");

        switch (result) {
            case SUCCESS -> {
                player.sendMessage(prefix + "§aEnchant §e" + enchant.getDisplayName() + " §aberhasil dipasang!");
                player.playSound(player.getLocation(), Sound.BLOCK_ENCHANTMENT_TABLE_USE, 1f, 1f);
                // Consume the enchant book
                if (cursor.getAmount() <= 1) {
                    event.getView().setCursor(null);
                } else {
                    cursor.setAmount(cursor.getAmount() - 1);
                }
                // Refresh the item in slot
                event.getView().setItem(event.getRawSlot(), target);
            }
            case WRONG_ITEM -> player.sendMessage(prefix + "§cItem ini tidak bisa menerima enchant tersebut!");
            case MAX_ENCHANTS -> player.sendMessage(prefix + "§cItem sudah mencapai batas maksimum enchant (8)!");
            case MAX_TIER -> player.sendMessage(prefix + "§cItem sudah mencapai batas tier Ultimate/God (2) atau Secret (1)!");
            case KEY_CONFLICT -> player.sendMessage(prefix + "§cKonflik! Enchant lain sudah menggunakan tombol aktif yang sama!");
            case ALREADY_HAS -> player.sendMessage(prefix + "§cItem sudah memiliki enchant tersebut!");
            case TIER_DOWNGRADE -> player.sendMessage(prefix + "§cTidak bisa menambahkan Mining enchant lebih lemah! Upgrade sudah ada.");
        }
    }
}
