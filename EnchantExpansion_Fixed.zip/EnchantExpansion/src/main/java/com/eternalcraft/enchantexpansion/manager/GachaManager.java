package com.eternalcraft.enchantexpansion.manager;

import com.eternalcraft.enchantexpansion.EnchantExpansionPlugin;
import com.eternalcraft.enchantexpansion.data.CustomEnchantData;
import com.eternalcraft.enchantexpansion.enums.EnchantTier;
import com.eternalcraft.enchantexpansion.registry.EnchantRegistry;
import com.eternalcraft.enchantexpansion.util.ItemUtil;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

import java.util.List;
import java.util.Random;

public class GachaManager {

    private final EnchantExpansionPlugin plugin;
    private final Random random = new Random();

    public GachaManager(EnchantExpansionPlugin plugin) {
        this.plugin = plugin;
    }

    public GachaResult openGacha(Player player, EnchantTier tier) {
        // Check XP cost
        int xpCost = tier.getXpPrice();
        if (xpCost > 0 && player.getTotalExperience() < xpCost) {
            return new GachaResult(false, null, 0, 0, "XP tidak cukup! Butuh " + xpCost + " XP.");
        }

        // Calculate success/fail rate (random each time as per spec)
        int successRate = random.nextInt(100) + 1; // 1-100
        int failRate = random.nextInt(100);        // 0-99

        // Determine if success
        boolean success = random.nextBoolean(); // both rates are random, so overall 50/50 base
        // Weight by tier: higher tier = lower base success
        double tierSuccessChance = switch (tier) {
            case NORMAL -> 0.80;
            case GOOD -> 0.70;
            case ELITE -> 0.60;
            case DIVINE -> 0.50;
            case ULTIMATE -> 0.40;
            case GOD -> 0.30;
            case SPECIAL -> 1.0; // admin only
            case SECRET -> 1.0; // ritual already paid the cost
        };

        success = random.nextDouble() < tierSuccessChance;

        if (!success) {
            // Deduct XP anyway (gamble!)
            if (xpCost > 0) deductXP(player, xpCost);
            player.playSound(player.getLocation(), Sound.ENTITY_VILLAGER_NO, 1f, 1f);
            return new GachaResult(false, null, successRate, failRate,
                    "§cGagal! Lebih beruntung lain kali.");
        }

        // Pick a random enchant from this tier
        List<CustomEnchantData> available = EnchantRegistry.getByTier(tier);
        if (available.isEmpty()) {
            return new GachaResult(false, null, successRate, failRate, "§cTidak ada enchant tersedia!");
        }

        CustomEnchantData chosen = available.get(random.nextInt(available.size()));
        ItemStack enchantBook = ItemUtil.createEnchantBook(chosen);

        // Deduct XP
        if (xpCost > 0) deductXP(player, xpCost);

        // Give item
        player.getInventory().addItem(enchantBook);
        player.playSound(player.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, 1f, 1.5f);
        player.sendMessage("§6✦ §e" + chosen.getDisplayName() + " §6✦ §7diperoleh dari gacha " + tier.getColoredName() + "§7!");

        return new GachaResult(true, chosen, successRate, failRate,
                "§aHasil: §e" + chosen.getDisplayName());
    }

    private void deductXP(Player player, int amount) {
        // Deduct XP levels simply via giveExp with negative value
        int currentLevel = player.getLevel();
        float currentExp = player.getExp();
        // Convert levels to XP and subtract
        int totalXp = player.getTotalExperience();
        player.setTotalExperience(Math.max(0, totalXp - amount));
        // Bukkit will auto-sync levels from totalExperience on next tick, 
        // but we manually sync now
        int newTotal = Math.max(0, totalXp - amount);
        player.setLevel(0);
        player.setTotalExperience(0);
        player.giveExp(newTotal);
    }

    public record GachaResult(boolean success, CustomEnchantData enchant, int successRate, int failRate, String message) {}
}
