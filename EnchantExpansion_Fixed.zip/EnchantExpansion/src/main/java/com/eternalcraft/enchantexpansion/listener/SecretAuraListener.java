package com.eternalcraft.enchantexpansion.listener;

import com.eternalcraft.enchantexpansion.EnchantExpansionPlugin;
import com.eternalcraft.enchantexpansion.util.PDCUtil;
import org.bukkit.Particle;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerItemHeldEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.scheduler.BukkitRunnable;

import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

public class SecretAuraListener implements Listener {

    private final EnchantExpansionPlugin plugin;
    private final Set<UUID> auraActive = new HashSet<>();

    public SecretAuraListener(EnchantExpansionPlugin plugin) {
        this.plugin = plugin;

        // Tick aura for players holding secret gacha
        new BukkitRunnable() {
            @Override
            public void run() {
                for (Player player : org.bukkit.Bukkit.getOnlinePlayers()) {
                    ItemStack held = player.getInventory().getItemInMainHand();
                    String tier = PDCUtil.getGachaTier(held);
                    if ("SECRET".equals(tier)) {
                        spawnSecretAura(player);
                    }
                }
            }
        }.runTaskTimer(plugin, 10L, 10L);
    }

    private void spawnSecretAura(Player player) {
        org.bukkit.Location loc = player.getLocation().add(0, 1, 0);

        // Dark soul particles rising from ground
        player.getWorld().spawnParticle(Particle.SOUL, loc, 5, 0.5, 0.5, 0.5, 0.02);
        player.getWorld().spawnParticle(Particle.SOUL_FIRE_FLAME, loc, 3, 0.3, 0.3, 0.3, 0.01);
        player.getWorld().spawnParticle(Particle.SMOKE, loc, 8, 0.3, 0.5, 0.3, 0.03);

        // Spiral particles
        double angle = (plugin.getServer().getCurrentTick() % 72) * 5 * Math.PI / 180;
        org.bukkit.Location ring = loc.clone().add(
                Math.cos(angle) * 0.8, 0, Math.sin(angle) * 0.8);
        player.getWorld().spawnParticle(Particle.WITCH, ring, 2, 0.05, 0.05, 0.05);
    }

    @EventHandler
    public void onHeld(PlayerItemHeldEvent event) {
        // Force update when switching item to SECRET gacha
        Player player = event.getPlayer();
        ItemStack newItem = player.getInventory().getItem(event.getNewSlot());
        String tier = PDCUtil.getGachaTier(newItem);
        if ("SECRET".equals(tier)) {
            player.sendMessage("§0§l... kamu merasakannya ...");
        }
    }
}
