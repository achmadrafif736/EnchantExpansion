package com.eternalcraft.enchantexpansion.listener;

import com.eternalcraft.enchantexpansion.EnchantExpansionPlugin;
import com.eternalcraft.enchantexpansion.manager.ActiveSkillManager;
import com.eternalcraft.enchantexpansion.manager.EnchantManager;
import com.eternalcraft.enchantexpansion.listener.ProjectileEnchantListener;
import org.bukkit.*;
import org.bukkit.block.Block;
import org.bukkit.block.BlockFace;
import org.bukkit.block.data.Ageable;
import org.bukkit.entity.*;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.player.*;
import org.bukkit.inventory.ItemStack;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scheduler.BukkitTask;
import org.bukkit.util.Vector;

import java.util.*;

public class ActiveSkillListener implements Listener {

    private final EnchantExpansionPlugin plugin;
    private final EnchantManager em;
    private final ActiveSkillManager asm;
    private final Random random = new Random();
    private ProjectileEnchantListener projListener;

    public void setProjectileListener(ProjectileEnchantListener pl) {
        this.projListener = pl;
    }

    // Track hold state for HOLD key
    private final Set<UUID> holdTriggered = new HashSet<>();
    // Track run+click
    private final Map<UUID, Long> lastRightClick = new HashMap<>();

    public ActiveSkillListener(EnchantExpansionPlugin plugin, EnchantManager em, ActiveSkillManager asm) {
        this.plugin = plugin;
        this.em = em;
        this.asm = asm;
    }

    @EventHandler
    public void onInteract(PlayerInteractEvent event) {
        if (event.getAction() != Action.RIGHT_CLICK_AIR && event.getAction() != Action.RIGHT_CLICK_BLOCK) return;
        Player player = event.getPlayer();
        ItemStack main = player.getInventory().getItemInMainHand();
        ItemStack chest = player.getInventory().getArmorContents()[2];
        ItemStack leggings = player.getInventory().getArmorContents()[1];
        boolean sneaking = player.isSneaking();
        boolean emptyHand = main == null || main.getType() == Material.AIR;
        boolean isRunning = player.getVelocity().lengthSquared() > 0.04;

        // ============ SWORD SKILLS ============

        // Walk Speed Override (Click, Sword)
        if (!sneaking && em.hasEnchant(main, "walk_speed_override")) {
            if (!asm.isOnCooldown(player, "walk_speed_override")) {
                activateWalkSpeedOverride(player);
                asm.setCooldown(player, "walk_speed_override", 20 * 25);
                event.setCancelled(true);
                return;
            } else {
                player.sendMessage("§cCooldown: " + asm.getRemainingCooldownSeconds(player, "walk_speed_override") + "s");
                return;
            }
        }

        // Evoker Fangs (Sneak+Click, Sword)
        if (sneaking && em.hasEnchant(main, "evoker_fangs")) {
            if (!asm.isOnCooldown(player, "evoker_fangs")) {
                activateEvokerFangs(player);
                asm.setCooldown(player, "evoker_fangs", 20 * 5);
                event.setCancelled(true);
                return;
            } else {
                player.sendMessage("§cCooldown Evoker Fangs: " + asm.getRemainingCooldownSeconds(player, "evoker_fangs") + "s");
                return;
            }
        }

        // Infinity Hole - Sword version (Sneak+Click)
        if (sneaking && em.hasEnchant(main, "infinity_hole")) {
            if (!asm.isOnCooldown(player, "infinity_hole")) {
                activateInfinityHole(player);
                asm.setCooldown(player, "infinity_hole", 20 * 60);
                event.setCancelled(true);
                return;
            }
        }

        // Super Charge (Hold 2s, Sword)
        if (!sneaking && em.hasEnchant(main, "super_charge") && !holdTriggered.contains(player.getUniqueId())) {
            if (!asm.isOnCooldown(player, "super_charge")) {
                holdTriggered.add(player.getUniqueId());
                asm.startHoldCharge(player, 40L, () -> { // 2 seconds
                    holdTriggered.remove(player.getUniqueId());
                    activateSuperCharge(player);
                    asm.setCooldown(player, "super_charge", 20 * 15);
                });
                player.sendMessage("§6Charging Super Charge...");
            }
        }

        // ============ MACE SKILLS ============

        // Destruction from the Sky (Sneak+Click, Mace)
        if (sneaking && em.hasEnchant(main, "destruction_from_sky")) {
            if (!asm.isOnCooldown(player, "destruction_from_sky")) {
                activateDestructionFromSky(player);
                asm.setCooldown(player, "destruction_from_sky", 20 * 50);
                event.setCancelled(true);
                return;
            } else {
                player.sendMessage("§cCooldown: " + asm.getRemainingCooldownSeconds(player, "destruction_from_sky") + "s");
                return;
            }
        }

        // ============ HOE SKILLS ============

        // Auto-Plant (Sneak+Click, Hoe)
        if (sneaking && em.hasEnchant(main, "auto_plant")) {
            if (!asm.isOnCooldown(player, "auto_plant")) {
                activateAutoPlant(player);
                asm.setCooldown(player, "auto_plant", 20 * 5);
                event.setCancelled(true);
                return;
            }
        }

        // ============ ARROW RAIN (Bow/Crossbow - Sneak+Hold) ============
        if (sneaking && (em.hasEnchant(main, "arrow_rain"))) {
            if (!asm.isOnCooldown(player, "arrow_rain") && !asm.isCharging(player)) {
                asm.startHoldCharge(player, 20L, () -> {
                    boolean hasExplosion = em.hasEnchant(main, "explosion_arrow");
                    if (projListener != null) projListener.activateArrowRain(player, hasExplosion);
                    asm.setCooldown(player, "arrow_rain", 20 * 20);
                });
            } else if (asm.isOnCooldown(player, "arrow_rain")) {
                player.sendMessage("§cCooldown Arrow Rain: " + asm.getRemainingCooldownSeconds(player, "arrow_rain") + "s");
            }
            event.setCancelled(true);
            return;
        }

        // ============ CHESTPLATE SKILLS (empty hand required) ============
        if (!emptyHand || chest == null) return;

        // Demonic Takaz Burst (Sneak+Click, Chestplate, empty hand)
        if (sneaking && em.hasEnchant(chest, "demonic_takaz")) {
            if (!asm.isOnCooldown(player, "demonic_takaz")) {
                if (projListener != null) projListener.activateDemonicBurst(player);
                asm.setCooldown(player, "demonic_takaz", 20 * 20);
                event.setCancelled(true);
                return;
            } else {
                player.sendMessage("§4Cooldown Demonic Burst: " + asm.getRemainingCooldownSeconds(player, "demonic_takaz") + "s");
                return;
            }
        }

        // Wither Storm Laser (Sneak+Hold — override existing sneak_hold check)
        if (sneaking && em.hasEnchant(chest, "wither_storm") && !asm.isCharging(player)) {
            if (!asm.isOnCooldown(player, "wither_storm_laser")) {
                asm.startHoldCharge(player, 20L, () -> {
                    if (projListener != null) projListener.activateWitherStormLaser(player);
                    asm.setCooldown(player, "wither_storm_laser", 20 * 30);
                });
            }
        }

        // Herobrine Teleport (Click, not sneak, empty hand, not charging)
        if (!sneaking && em.hasEnchant(chest, "herobrine") && !asm.isToggled(player, "kamehameha")) {
            if (!asm.isOnCooldown(player, "herobrine_teleport")) {
                if (projListener != null) projListener.activateHerobrineTeleport(player);
                asm.setCooldown(player, "herobrine_teleport", 20 * 30);
                event.setCancelled(true);
                return;
            }
        }

        // Sonic Boom (Sneak+Click, Chestplate, empty hand)
        if (sneaking && em.hasEnchant(chest, "sonic_boom")) {
            if (!asm.isOnCooldown(player, "sonic_boom")) {
                activateSonicBoom(player);
                asm.setCooldown(player, "sonic_boom", 20 * 20);
                event.setCancelled(true);
                return;
            } else {
                player.sendMessage("§cCooldown Sonic Boom: " + asm.getRemainingCooldownSeconds(player, "sonic_boom") + "s");
                return;
            }
        }

        // Dragon Breath (Sneak+Click, Chestplate, empty hand)
        if (sneaking && em.hasEnchant(chest, "dragon_breath_skill")) {
            if (!asm.isOnCooldown(player, "dragon_breath_skill")) {
                activateDragonBreath(player);
                asm.setCooldown(player, "dragon_breath_skill", 20 * 15);
                event.setCancelled(true);
                return;
            }
        }

        // Rasengan (Sneak+Click, Chestplate, empty hand)
        if (sneaking && em.hasEnchant(chest, "rasengan")) {
            if (!asm.isOnCooldown(player, "rasengan")) {
                activateRasengan(player);
                asm.setCooldown(player, "rasengan", 20 * 30);
                event.setCancelled(true);
                return;
            } else {
                player.sendMessage("§cCooldown Rasengan: " + asm.getRemainingCooldownSeconds(player, "rasengan") + "s");
                return;
            }
        }

        // Infinity Hole - Chestplate (Sneak+Click, empty hand)
        if (sneaking && em.hasEnchant(chest, "infinity_hole")) {
            if (!asm.isOnCooldown(player, "infinity_hole")) {
                activateInfinityHole(player);
                asm.setCooldown(player, "infinity_hole", 20 * 60);
                event.setCancelled(true);
                return;
            }
        }

        // Abyssal Laser (Hold/Toggle, Chestplate, empty hand)
        if (!sneaking && em.hasEnchant(chest, "abyssal_laser")) {
            if (asm.isToggled(player, "abyssal_laser")) {
                asm.stopToggle(player);
                player.sendMessage("§9Abyssal Laser §7— dimatikan.");
            } else {
                BukkitTask task = new BukkitRunnable() {
                    @Override
                    public void run() {
                        if (!player.isOnline() || !asm.isToggled(player, "abyssal_laser")) {
                            cancel(); return;
                        }
                        fireAbyssalLaser(player);
                    }
                }.runTaskTimer(plugin, 0L, 20L);
                asm.startToggle(player, "abyssal_laser", task);
                player.sendMessage("§9Abyssal Laser §7— aktif! Klik lagi untuk matikan.");
            }
            event.setCancelled(true);
            return;
        }

        // Kamehameha (Hold/Toggle, Chestplate, empty hand)
        if (!sneaking && em.hasEnchant(chest, "kamehameha")) {
            if (asm.isToggled(player, "kamehameha")) {
                asm.stopToggle(player);
                player.sendMessage("§bKamehameha §7— beam dihentikan.");
            } else {
                if (!asm.isOnCooldown(player, "kamehameha")) {
                    player.sendMessage("§bMengumpulkan energi... (2 detik)");
                    asm.startHoldCharge(player, 40L, () -> {
                        player.sendMessage("§b§l✦ KAMEHAMEHA! ✦");
                        player.playSound(player.getLocation(), Sound.ENTITY_ELDER_GUARDIAN_CURSE, 1f, 2f);
                        BukkitTask task = new BukkitRunnable() {
                            int ticks = 0;
                            @Override
                            public void run() {
                                ticks++;
                                if (!player.isOnline() || ticks > 60) { // max 3 seconds
                                    asm.stopToggle(player);
                                    cancel(); return;
                                }
                                fireKamehameha(player);
                            }
                        }.runTaskTimer(plugin, 0L, 20L);
                        asm.startToggle(player, "kamehameha", task);
                        asm.setCooldown(player, "kamehameha", 20 * 40);
                    });
                } else {
                    player.sendMessage("§cCooldown: " + asm.getRemainingCooldownSeconds(player, "kamehameha") + "s");
                }
            }
            event.setCancelled(true);
            return;
        }

        // Click (not sneak), Herobrine active 1: Herobrine's Gaze
        if (!sneaking && em.hasEnchant(chest, "herobrine")) {
            activateHerobrinegaze(player);
            event.setCancelled(true);
            return;
        }

        // Wither Skull (Sneak+Hold -> detected as Sneak+Click here for simplicity)
        if (sneaking && em.hasEnchant(chest, "wither_skull_skill")) {
            if (!asm.isOnCooldown(player, "wither_skull_skill")) {
                fireWitherSkull(player);
                asm.setCooldown(player, "wither_skull_skill", 20 * 25);
                event.setCancelled(true);
                return;
            }
        }

        // Wither Storm Active 1: Storm Unleash (Sneak+Click, empty hand)
        if (sneaking && em.hasEnchant(chest, "wither_storm")) {
            if (!asm.isOnCooldown(player, "wither_storm_unleash")) {
                activateWitherStormUnleash(player);
                asm.setCooldown(player, "wither_storm_unleash", 20 * 30);
                event.setCancelled(true);
                return;
            }
        }

        // Herobrine Active 3: Soul Reaper (Run+Click)
        if (!sneaking && isRunning && em.hasEnchant(chest, "herobrine")) {
            if (!asm.isOnCooldown(player, "herobrine_soul_reaper")) {
                activateSoulReaper(player);
                asm.setCooldown(player, "herobrine_soul_reaper", 20 * 30);
                event.setCancelled(true);
                return;
            }
        }
    }

    @EventHandler
    public void onSneak(PlayerToggleSneakEvent event) {
        Player player = event.getPlayer();
        ItemStack chest = player.getInventory().getArmorContents()[2];
        boolean emptyHand = player.getInventory().getItemInMainHand().getType() == Material.AIR;

        if (!event.isSneaking()) {
            // Player started sneaking - cancel super charge if not done yet
            if (asm.isCharging(player)) {
                asm.cancelHold(player);
                holdTriggered.remove(player.getUniqueId());
                player.sendMessage("§cCharge dibatalkan.");
            }
            return;
        }

        // Sneak+Hold: dark summoning (Herobrine)
        if (emptyHand && chest != null && em.hasEnchant(chest, "herobrine")) {
            if (!asm.isOnCooldown(player, "herobrine_summon") && !asm.isCharging(player)) {
                asm.startHoldCharge(player, 40L, () -> {
                    activateDarkSummoning(player);
                    asm.setCooldown(player, "herobrine_summon", 20 * 60);
                });
            }
        }

        // Sneak+Hold: Wither Storm Tornado Vortex
        if (emptyHand && chest != null && em.hasEnchant(chest, "wither_storm")) {
            if (!asm.isOnCooldown(player, "wither_storm_tornado") && !asm.isCharging(player)) {
                asm.startHoldCharge(player, 40L, () -> {
                    activateWitherTornado(player);
                    asm.setCooldown(player, "wither_storm_tornado", 20 * 45);
                });
            }
        }
    }

    @EventHandler
    public void onJump(PlayerMoveEvent event) {
        Player player = event.getPlayer();
        // Detect jump: upward Y velocity transition
        if (!event.getPlayer().isSneaking()) return;
        Vector vel = player.getVelocity();
        if (vel.getY() > 0.3) {
            // Sneak+Jump triggered
            asm.armSneakJump(player);
        }
    }

    @EventHandler
    public void onSneakJumpCheck(PlayerMoveEvent event) {
        Player player = event.getPlayer();
        if (!asm.consumeSneakJump(player)) return;

        ItemStack chest = player.getInventory().getArmorContents()[2];
        if (chest == null) return;
        boolean emptyHand = player.getInventory().getItemInMainHand().getType() == Material.AIR;
        if (!emptyHand) return;

        // Wither Storm: World Breaker (Sneak+Jump)
        if (em.hasEnchant(chest, "wither_storm")) {
            if (!asm.isOnCooldown(player, "wither_storm_worldbreaker")) {
                activateWorldBreaker(player);
                asm.setCooldown(player, "wither_storm_worldbreaker", 20 * 120);
            }
        }
    }

    // ======================== SKILL IMPLEMENTATIONS ========================

    private void activateWalkSpeedOverride(Player player) {
        player.sendMessage("§6Walk Speed Override §7— Dash!");
        player.playSound(player.getLocation(), Sound.ENTITY_PLAYER_ATTACK_SWEEP, 1f, 2f);

        Vector dir = player.getLocation().getDirection().setY(0).normalize().multiply(0.8);
        player.setVelocity(dir);

        BukkitTask task = new BukkitRunnable() {
            int ticks = 0;
            @Override
            public void run() {
                ticks++;
                if (!player.isOnline() || ticks >= 25) { cancel(); return; }

                // Damage + knockback + fire any mob in path
                for (LivingEntity e : player.getLocation().getNearbyLivingEntities(2)) {
                    if (e == player) continue;
                    e.damage(6.0, player);
                    e.setFireTicks(60);
                    e.setVelocity(dir.clone().multiply(1.5).add(new Vector(0, 0.5, 0)));
                }

                player.getWorld().spawnParticle(Particle.SWEEP_ATTACK, player.getLocation(), 3, 0.5, 0.2, 0.5);
                player.setVelocity(dir);
            }
        }.runTaskTimer(plugin, 0L, 1L);
    }

    private void activateEvokerFangs(Player player) {
        player.sendMessage("§dEvoker Fangs §7— Memanggil rahang!");
        player.playSound(player.getLocation(), Sound.ENTITY_EVOKER_CAST_SPELL, 1f, 1f);

        Location start = player.getLocation();
        Vector direction = player.getLocation().getDirection().setY(0).normalize();

        new BukkitRunnable() {
            int step = 0;
            @Override
            public void run() {
                step++;
                if (step > 10) { cancel(); return; }

                Location loc = start.clone().add(direction.clone().multiply(step));
                player.getWorld().spawnEntity(loc, EntityType.EVOKER_FANGS);
            }
        }.runTaskTimer(plugin, 0L, 2L);
    }

    private void activateDestructionFromSky(Player player) {
        player.sendMessage("§cDestruction from the Sky §7— Terbang!");
        player.playSound(player.getLocation(), Sound.ENTITY_FIREWORK_ROCKET_LAUNCH, 1f, 0.5f);

        player.setVelocity(new Vector(0, 3, 0));

        new BukkitRunnable() {
            int ticks = 0;
            boolean falling = false;

            @Override
            public void run() {
                ticks++;
                if (!player.isOnline()) { cancel(); return; }

                if (ticks > 20 && !falling) {
                    falling = true;
                    player.setVelocity(new Vector(0, -3, 0));
                }

                if (falling && player.isOnGround()) {
                    // Explode!
                    Location loc = player.getLocation();
                    player.getWorld().spawnParticle(Particle.EXPLOSION, loc, 10, 2, 0.5, 2);
                    player.getWorld().spawnParticle(Particle.LAVA, loc, 30, 3, 1, 3);
                    player.getWorld().playSound(loc, Sound.ENTITY_GENERIC_EXPLODE, 1.5f, 0.8f);

                    // AOE damage
                    for (LivingEntity e : loc.getNearbyLivingEntities(5)) {
                        if (e == player) continue;
                        e.damage(10.0, player);
                        e.setVelocity(e.getLocation().subtract(loc).toVector().normalize().multiply(2));
                    }

                    cancel();
                }

                if (ticks > 100) cancel();
            }
        }.runTaskTimer(plugin, 5L, 1L);
    }

    private void activateSuperCharge(Player player) {
        player.sendMessage("§6§lSuper Charge §7— Menerobos!");
        player.playSound(player.getLocation(), Sound.ENTITY_PLAYER_ATTACK_CRIT, 1f, 0.5f);

        Vector dir = player.getLocation().getDirection().setY(0).normalize().multiply(1.2);
        player.setVelocity(dir);

        new BukkitRunnable() {
            int ticks = 0;
            @Override
            public void run() {
                ticks++;
                if (!player.isOnline() || ticks >= 10) { cancel(); return; }

                for (LivingEntity e : player.getLocation().getNearbyLivingEntities(1.5)) {
                    if (e == player) continue;
                    e.damage(12.0, player);
                    e.setVelocity(dir.clone().multiply(2).add(new Vector(0, 0.5, 0)));
                }

                player.getWorld().spawnParticle(Particle.CRIT, player.getLocation(), 5, 0.3, 0.3, 0.3);
                player.setVelocity(dir.clone().multiply(0.9));
            }
        }.runTaskTimer(plugin, 0L, 1L);
    }

    private void activateSonicBoom(Player player) {
        player.sendMessage("§e§lSONIC BOOM!");
        player.playSound(player.getLocation(), Sound.ENTITY_WARDEN_SONIC_BOOM, 1f, 1f);

        Location loc = player.getLocation();
        Vector dir = player.getLocation().getDirection().setY(0).normalize();

        player.getWorld().spawnParticle(Particle.SCULK_SOUL, loc, 50, 3, 1, 3, 0.1);

        // Cone of effect in front of player
        for (LivingEntity e : loc.getNearbyLivingEntities(8)) {
            if (e == player) continue;
            Vector toEntity = e.getLocation().subtract(loc).toVector().normalize();
            double dot = dir.dot(toEntity);
            if (dot > 0.3) { // In front of player (60 degree cone)
                e.damage(25.0, player); // 50% of Warden damage (~50)
                e.setVelocity(dir.clone().multiply(3).add(new Vector(0, 1, 0)));
            }
        }
    }

    private void activateDragonBreath(Player player) {
        player.sendMessage("§5Dragon Breath §7— Semburan naga!");
        player.playSound(player.getLocation(), Sound.ENTITY_ENDER_DRAGON_GROWL, 1f, 1f);

        Location eyeLoc = player.getEyeLocation();
        Vector dir = eyeLoc.getDirection().normalize();

        new BukkitRunnable() {
            int ticks = 0;
            @Override
            public void run() {
                ticks++;
                if (ticks > 40 || !player.isOnline()) { cancel(); return; }

                // Spawn dragon breath cloud moving forward
                Location cloudLoc = eyeLoc.clone().add(dir.clone().multiply(ticks * 0.3));
                player.getWorld().spawnParticle(Particle.DRAGON_BREATH, cloudLoc, 20, 0.5, 0.5, 0.5, 0.02);

                // Damage entities in cloud
                for (LivingEntity e : cloudLoc.getNearbyLivingEntities(2)) {
                    if (e == player) continue;
                    e.damage(0.5, player);
                    e.addPotionEffect(new PotionEffect(PotionEffectType.INSTANT_DAMAGE, 1, 0));
                }
            }
        }.runTaskTimer(plugin, 0L, 1L);
    }

    private void activateRasengan(Player player) {
        player.sendMessage("§a§l⚡ RASENGAN! ⚡");
        player.playSound(player.getLocation(), Sound.ENTITY_PLAYER_ATTACK_SWEEP, 2f, 2f);

        Location loc = player.getLocation();
        Vector dir = player.getLocation().getDirection().normalize();

        // Spinning particles at hand
        new BukkitRunnable() {
            int step = 0;
            @Override
            public void run() {
                step++;
                if (step > 20 || !player.isOnline()) { cancel(); return; }
                double angle = step * 30 * Math.PI / 180;
                Location pLoc = player.getEyeLocation().add(dir.clone().multiply(step * 0.3));
                player.getWorld().spawnParticle(Particle.CLOUD, pLoc.clone().add(
                        Math.cos(angle) * 0.5, Math.sin(angle) * 0.5, 0), 3, 0.1, 0.1, 0.1);
                player.getWorld().spawnParticle(Particle.CRIT_MAGIC, pLoc, 5, 0.3, 0.3, 0.3);

                // Hit entities
                for (LivingEntity e : pLoc.getNearbyLivingEntities(1.5)) {
                    if (e == player) continue;
                    // Calculate damage 15-20
                    double dmg = 15 + random.nextDouble() * 5;
                    e.damage(dmg, player);
                    e.setVelocity(e.getLocation().subtract(player.getLocation()).toVector().normalize().multiply(6));
                    player.sendMessage("§aRasengan hit! §e" + String.format("%.1f", dmg) + " damage!");
                    cancel();
                }
            }
        }.runTaskTimer(plugin, 0L, 1L);

        // Also do area explosion at end
        new BukkitRunnable() {
            @Override
            public void run() {
                Location target = player.getEyeLocation().add(dir.clone().multiply(6));
                player.getWorld().spawnParticle(Particle.EXPLOSION, target, 5, 1, 1, 1);
                player.getWorld().playSound(target, Sound.ENTITY_GENERIC_EXPLODE, 1f, 1.5f);
                for (LivingEntity e : target.getNearbyLivingEntities(3)) {
                    if (e == player) continue;
                    e.damage(18, player);
                    e.setVelocity(e.getLocation().subtract(target).toVector().normalize().multiply(6));
                }
            }
        }.runTaskLater(plugin, 20L);
    }

    private void activateInfinityHole(Player player) {
        if (asm.hasBlackHole(player)) {
            asm.endBlackHole(player);
            player.sendMessage("§8Infinity Hole §7— Black hole dibubarkan.");
            return;
        }

        player.sendMessage("§8§l☽ INFINITY HOLE ☽ §7— Black hole dibuka!");
        player.playSound(player.getLocation(), Sound.ENTITY_ENDERMAN_TELEPORT, 2f, 0.5f);

        Location holeLoc = player.getTargetBlockExact(20) != null ?
                player.getTargetBlockExact(20).getLocation().add(0, 1, 0) :
                player.getEyeLocation().add(player.getLocation().getDirection().multiply(10));

        BukkitTask task = new BukkitRunnable() {
            int ticks = 0;

            @Override
            public void run() {
                ticks++;
                if (ticks > 200 || !player.isOnline()) { // 10 seconds
                    // Final explosion
                    player.getWorld().spawnParticle(Particle.EXPLOSION, holeLoc, 15, 3, 3, 3);
                    player.getWorld().playSound(holeLoc, Sound.ENTITY_GENERIC_EXPLODE, 2f, 0.5f);
                    for (LivingEntity e : holeLoc.getNearbyLivingEntities(10)) {
                        if (e == player) continue;
                        e.damage(30.0, player);
                        e.setVelocity(e.getLocation().subtract(holeLoc).toVector().normalize().multiply(5));
                    }
                    asm.endBlackHole(player);
                    cancel();
                    return;
                }

                // Spiral particles
                double angle = ticks * 15 * Math.PI / 180;
                double radius = Math.max(0.1, 2 - ticks * 0.01);
                player.getWorld().spawnParticle(Particle.PORTAL, holeLoc, 5, radius, radius, radius, 0.05);
                player.getWorld().spawnParticle(Particle.REVERSE_PORTAL, holeLoc, 3, radius * 0.5, radius * 0.5, radius * 0.5);
                player.getWorld().spawnParticle(Particle.SOUL, holeLoc, 2, radius, 0.5, radius, 0.01);

                // Pull entities
                for (LivingEntity e : holeLoc.getNearbyLivingEntities(15)) {
                    if (e == player) continue;
                    Vector pull = holeLoc.subtract(e.getLocation()).toVector().normalize().multiply(0.4);
                    e.setVelocity(pull);
                    e.damage(0.5, player); // Continuous damage
                }
            }
        }.runTaskTimer(plugin, 0L, 1L);

        asm.startBlackHole(player, task);
    }

    private void fireAbyssalLaser(Player player) {
        Location eyeLoc = player.getEyeLocation();
        Vector dir = eyeLoc.getDirection().normalize();

        for (int i = 0; i < 20; i++) {
            Location point = eyeLoc.clone().add(dir.clone().multiply(i * 0.5));
            player.getWorld().spawnParticle(Particle.CRIT, point, 3, 0.05, 0.05, 0.05);
            player.getWorld().spawnParticle(Particle.WITCH, point, 1);

            for (LivingEntity e : point.getNearbyLivingEntities(0.5)) {
                if (e == player) continue;
                e.damage(2.0, player); // ~1/second with 20L interval
            }
        }

        player.getWorld().playSound(player.getLocation(), Sound.ENTITY_GUARDIAN_ATTACK, 0.3f, 2f);
    }

    private void fireKamehameha(Player player) {
        Location eyeLoc = player.getEyeLocation();
        Vector dir = eyeLoc.getDirection().normalize();

        // Long beam
        for (int i = 0; i < 40; i++) {
            Location point = eyeLoc.clone().add(dir.clone().multiply(i * 0.5));

            if (i % 2 == 0) {
                player.getWorld().spawnParticle(Particle.EXPLOSION_EMITTER, point, 1, 0.3, 0.3, 0.3);
            }
            player.getWorld().spawnParticle(Particle.CRIT_MAGIC, point, 5, 0.3, 0.3, 0.3, 0.1);

            if (point.getBlock().getType().isSolid()) break;

            for (LivingEntity e : point.getNearbyLivingEntities(1)) {
                if (e == player) continue;
                e.damage(15.0, player);
            }
        }

        player.getWorld().playSound(player.getLocation(), Sound.ENTITY_ELDER_GUARDIAN_CURSE, 0.5f, 2f);
    }

    private void fireWitherSkull(Player player) {
        player.sendMessage("§8Wither Skull §7— Tembak!");
        player.playSound(player.getLocation(), Sound.ENTITY_WITHER_SHOOT, 1f, 1f);

        WitherSkull skull = (WitherSkull) player.getWorld().spawnEntity(player.getEyeLocation(), EntityType.WITHER_SKULL);
        skull.setDirection(player.getEyeLocation().getDirection().multiply(1.5));
        skull.setCharged(false);
        skull.setShooter(player);

        // Add wither effect on hit via separate listener if needed
        // For now, the skull deals explosion damage
    }

    private void activateHerobrinegaze(Player player) {
        // Find nearby mob/player
        Entity target = null;
        double minDist = 30;
        for (Entity e : player.getNearbyEntities(30, 30, 30)) {
            if (e == player || !(e instanceof LivingEntity)) continue;
            double d = e.getLocation().distanceSquared(player.getLocation());
            if (d < minDist * minDist) {
                minDist = d;
                target = e;
            }
        }

        if (target == null) {
            player.sendMessage("§8Tidak ada target dalam jangkauan.");
            return;
        }

        final Entity finalTarget = target;
        player.sendMessage("§8Herobrine's Gaze §7— Target dikunci! 3x damage selama 10 detik.");
        finalTarget.addScoreboardTag("herobrine_marked_" + player.getUniqueId());

        new BukkitRunnable() {
            @Override
            public void run() {
                finalTarget.removeScoreboardTag("herobrine_marked_" + player.getUniqueId());
            }
        }.runTaskLater(plugin, 200L);

        if (finalTarget instanceof LivingEntity le) {
            le.addPotionEffect(new PotionEffect(PotionEffectType.GLOWING, 200, 0));
        }
    }

    private void activateDarkSummoning(Player player) {
        player.sendMessage("§8Dark Summoning §7— Klon dipanggil!");
        player.playSound(player.getLocation(), Sound.ENTITY_ELDER_GUARDIAN_CURSE, 1f, 0.8f);

        for (int i = 0; i < 3; i++) {
            final int idx = i;
            new BukkitRunnable() {
                @Override
                public void run() {
                    double angle = idx * 120 * Math.PI / 180;
                    Location summonLoc = player.getLocation().clone().add(
                            Math.cos(angle) * 2, 0, Math.sin(angle) * 2);

                    // Spawn zombie as "clone" placeholder
                    Zombie clone = (Zombie) player.getWorld().spawnEntity(summonLoc, EntityType.ZOMBIE);
                    clone.setCustomName("§8Klon " + player.getName());
                    clone.setCustomNameVisible(true);
                    clone.setMaxHealth(40);
                    clone.setHealth(40);
                    clone.addPotionEffect(new PotionEffect(PotionEffectType.STRENGTH, 600, 2));
                    clone.addPotionEffect(new PotionEffect(PotionEffectType.SPEED, 600, 1));

                    player.getWorld().spawnParticle(Particle.SOUL, summonLoc.add(0, 1, 0), 20, 0.5, 0.5, 0.5, 0.05);

                    // Remove after 30s
                    new BukkitRunnable() {
                        @Override
                        public void run() {
                            if (!clone.isDead()) clone.remove();
                        }
                    }.runTaskLater(plugin, 600L);
                }
            }.runTaskLater(plugin, i * 10L);
        }
    }

    private void activateSoulReaper(Player player) {
        player.sendMessage("§0§lSOUL REAPER §7— Melesat!");
        player.playSound(player.getLocation(), Sound.ENTITY_ENDERMAN_TELEPORT, 1f, 0.5f);

        Vector dir = player.getLocation().getDirection().normalize();
        player.setVelocity(dir.clone().multiply(3));

        new BukkitRunnable() {
            int ticks = 0;
            final Set<UUID> hit = new HashSet<>();

            @Override
            public void run() {
                ticks++;
                if (ticks > 15 || !player.isOnline()) { cancel(); return; }

                player.getWorld().spawnParticle(Particle.SOUL, player.getLocation().add(0, 1, 0), 10, 0.3, 0.3, 0.3, 0.02);

                for (LivingEntity e : player.getLocation().getNearbyLivingEntities(2)) {
                    if (e == player || hit.contains(e.getUniqueId())) continue;
                    hit.add(e.getUniqueId());
                    e.damage(40.0, player); // 20 damage = 10 hearts
                    // Lifesteal: full heal
                    double maxHp = player.getAttribute(org.bukkit.attribute.Attribute.MAX_HEALTH).getValue();
                    player.setHealth(maxHp);
                }

                player.setVelocity(dir.clone().multiply(3 - ticks * 0.1));
            }
        }.runTaskTimer(plugin, 0L, 1L);
    }

    // ======================== WITHER STORM SKILLS ========================

    private void activateWitherStormUnleash(Player player) {
        player.sendMessage("§4§lWITHER STORM UNLEASH §7— Tengkorak Wither meledak!");
        player.playSound(player.getLocation(), Sound.ENTITY_WITHER_SPAWN, 1f, 0.5f);

        // Fire wither skulls in multiple directions
        for (int i = 0; i < 8; i++) {
            double angle = i * 45 * Math.PI / 180;
            Vector dir = new Vector(Math.cos(angle), 0.3, Math.sin(angle)).normalize();
            WitherSkull skull = (WitherSkull) player.getWorld().spawnEntity(player.getEyeLocation(), EntityType.WITHER_SKULL);
            skull.setDirection(dir.multiply(1.5));
            skull.setCharged(true);
            skull.setShooter(player);
        }

        player.getWorld().spawnParticle(Particle.EXPLOSION, player.getLocation().add(0, 1, 0), 20, 2, 2, 2);
    }

    private void activateWitherTornado(Player player) {
        player.sendMessage("§4Tornado Vortex §7— Tornado jiwa datang!");
        player.playSound(player.getLocation(), Sound.ENTITY_WITHER_AMBIENT, 1f, 0.5f);

        Location center = player.getLocation();

        new BukkitRunnable() {
            int ticks = 0;
            @Override
            public void run() {
                ticks += 2;
                if (ticks > 100 || !player.isOnline()) { cancel(); return; }

                double angle = ticks * 20 * Math.PI / 180;
                double radius = 4;
                for (int y = 0; y < 5; y++) {
                    Location pLoc = center.clone().add(
                            Math.cos(angle) * radius, y * 0.5, Math.sin(angle) * radius);
                    player.getWorld().spawnParticle(Particle.SOUL, pLoc, 3, 0.2, 0.2, 0.2);
                    player.getWorld().spawnParticle(Particle.SMOKE, pLoc, 2);
                }

                // Pull + damage nearby entities
                for (LivingEntity e : center.getNearbyLivingEntities(6)) {
                    if (e == player) continue;
                    Vector toCenter = center.clone().add(0, 2, 0).subtract(e.getLocation()).toVector();
                    e.setVelocity(toCenter.normalize().multiply(0.5).add(new Vector(0, 0.3, 0)));
                    if (ticks % 20 == 0) e.damage(4.0, player);
                    e.addPotionEffect(new PotionEffect(PotionEffectType.WITHER, 40, 0));
                }
            }
        }.runTaskTimer(plugin, 0L, 2L);
    }

    private void activateWorldBreaker(Player player) {
        player.sendMessage("§4§lWORLD BREAKER §7— Ledakan masif!");
        player.playSound(player.getLocation(), Sound.ENTITY_ENDER_DRAGON_DEATH, 2f, 0.5f);

        Location center = player.getLocation();

        new BukkitRunnable() {
            @Override
            public void run() {
                // Massive explosion
                player.getWorld().spawnParticle(Particle.EXPLOSION, center, 30, 5, 2, 5);
                player.getWorld().spawnParticle(Particle.SOUL, center, 100, 8, 4, 8, 0.1);
                player.getWorld().playSound(center, Sound.ENTITY_GENERIC_EXPLODE, 3f, 0.3f);
                player.getWorld().playSound(center, Sound.ENTITY_WITHER_DEATH, 2f, 0.5f);

                // Damage all nearby
                for (LivingEntity e : center.getNearbyLivingEntities(15)) {
                    if (e == player) continue;
                    double dist = e.getLocation().distance(center);
                    double dmg = 40 * (1 - dist / 15); // Falloff
                    e.damage(Math.max(10, dmg), player);
                    e.addPotionEffect(new PotionEffect(PotionEffectType.WITHER, 200, 1));
                    e.setVelocity(e.getLocation().subtract(center).toVector().normalize().multiply(4).add(new Vector(0, 2, 0)));
                }

                // Player protection
                player.addPotionEffect(new PotionEffect(PotionEffectType.RESISTANCE, 60, 4));
            }
        }.runTaskLater(plugin, 10L);
    }

    private void activateAutoPlant(Player player) {
        player.sendMessage("§2Auto-Plant §7— Menanam area 3x3x3!");
        Location center = player.getLocation();

        int planted = 0;
        for (int x = -1; x <= 1; x++) {
            for (int z = -1; z <= 1; z++) {
                for (int y = -1; y <= 1; y++) {
                    Block b = center.clone().add(x, y, z).getBlock();
                    if (b.getType() == Material.FARMLAND && b.getRelative(BlockFace.UP).getType() == Material.AIR) {
                        // Find a seed in inventory
                        for (Material seed : List.of(Material.WHEAT_SEEDS, Material.CARROT, Material.POTATO, Material.BEETROOT_SEEDS)) {
                            if (player.getInventory().contains(seed)) {
                                player.getInventory().removeItem(new ItemStack(seed, 1));
                                Material crop = getCropForSeed(seed);
                                if (crop != null) b.getRelative(BlockFace.UP).setType(crop);
                                planted++;
                                break;
                            }
                        }
                    }
                    // Also harvest mature crops
                    if (b.getBlockData() instanceof Ageable ag && ag.getAge() == ag.getMaximumAge()) {
                        b.breakNaturally();
                    }
                }
            }
        }

        player.sendMessage("§2Ditanam: §a" + planted + " §2tanaman.");
    }

    private Material getCropForSeed(Material seed) {
        return switch (seed) {
            case WHEAT_SEEDS -> Material.WHEAT;
            case CARROT -> Material.CARROTS;
            case POTATO -> Material.POTATOES;
            case BEETROOT_SEEDS -> Material.BEETROOTS;
            default -> null;
        };
    }
}
