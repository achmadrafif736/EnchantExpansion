package com.eternalcraft.enchantexpansion.manager;

import com.eternalcraft.enchantexpansion.EnchantExpansionPlugin;
import com.eternalcraft.enchantexpansion.enums.EnchantTier;
import com.eternalcraft.enchantexpansion.util.ItemUtil;
import com.eternalcraft.enchantexpansion.util.PDCUtil;
import org.bukkit.*;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.scheduler.BukkitRunnable;

import java.util.*;

public class RitualManager {

    private final EnchantExpansionPlugin plugin;
    private final Set<UUID> ritualInProgress = new HashSet<>();

    public RitualManager(EnchantExpansionPlugin plugin) {
        this.plugin = plugin;
    }

    public enum RitualResult {
        SUCCESS, WRONG_BIOME, MISSING_ITEMS, WRONG_HAND, ALREADY_IN_PROGRESS
    }

    public RitualResult startRitual(Player player) {
        if (ritualInProgress.contains(player.getUniqueId())) {
            return RitualResult.ALREADY_IN_PROGRESS;
        }

        // Check biome
        Biome biome = player.getLocation().getBlock().getBiome();
        if (biome != Biome.SOUL_SAND_VALLEY) {
            return RitualResult.WRONG_BIOME;
        }

        // Check mainhand has GOD gacha
        ItemStack mainHand = player.getInventory().getItemInMainHand();
        String gachaTier = PDCUtil.getGachaTier(mainHand);
        if (!"GOD".equals(gachaTier)) {
            return RitualResult.WRONG_HAND;
        }

        // Check ritual items in inventory
        if (!hasRitualItems(player)) {
            return RitualResult.MISSING_ITEMS;
        }

        // Start ritual
        ritualInProgress.add(player.getUniqueId());
        player.sendMessage("§5§l✦ Ritual dimulai... Jiwa-jiwa mulai mengumpul... ✦");

        new BukkitRunnable() {
            int tick = 0;
            final int DURATION = 100; // 5 seconds

            @Override
            public void run() {
                if (!player.isOnline()) { cancel(); ritualInProgress.remove(player.getUniqueId()); return; }

                tick += 5;

                // Particle effects
                Location loc = player.getLocation();
                player.getWorld().spawnParticle(Particle.SOUL, loc.clone().add(
                        Math.sin(tick * 0.2) * 3, 1 + tick * 0.01, Math.cos(tick * 0.2) * 3), 5, 0.1, 0.1, 0.1, 0.02);
                player.getWorld().spawnParticle(Particle.SOUL_FIRE_FLAME, loc.clone().add(0, 1, 0), 3, 0.5, 0.5, 0.5, 0.01);
                player.getWorld().spawnParticle(Particle.WITCH, loc, 10, 1, 1, 1);

                if (tick == 50) {
                    player.playSound(loc, Sound.ENTITY_WITHER_SPAWN, 1f, 0.5f);
                }

                if (tick >= DURATION) {
                    completeRitual(player, mainHand);
                    cancel();
                }
            }
        }.runTaskTimer(plugin, 0L, 5L);

        return RitualResult.SUCCESS;
    }

    private void completeRitual(Player player, ItemStack godGacha) {
        ritualInProgress.remove(player.getUniqueId());

        // Consume ritual items
        consumeRitualItems(player);

        // Consume the GOD gacha from hand
        player.getInventory().setItemInMainHand(null);

        // Give secret gacha
        ItemStack secretGacha = ItemUtil.createGachaItem(EnchantTier.SECRET);
        player.getInventory().addItem(secretGacha);

        // Epic effects
        Location loc = player.getLocation();
        player.getWorld().spawnParticle(Particle.EXPLOSION, loc.clone().add(0, 1, 0), 10, 0.5, 0.5, 0.5);
        player.getWorld().spawnParticle(Particle.SOUL, loc, 100, 2, 2, 2, 0.1);
        player.getWorld().spawnParticle(Particle.ENCHANT, loc, 200, 2, 2, 2, 0.5);
        player.getWorld().playSound(loc, Sound.ENTITY_ENDER_DRAGON_DEATH, 1f, 1f);
        player.getWorld().playSound(loc, Sound.ENTITY_WITHER_DEATH, 1f, 0.8f);

        // Broadcast
        for (Player online : Bukkit.getOnlinePlayers()) {
            online.sendMessage("§5§l⚠ " + player.getName() + " telah menyelesaikan Ritual Jiwa! ⚠");
        }
        player.sendMessage("§5§l✦ Ritual berhasil! Gacha Secret muncul dari kegelapan... ✦");
    }

    private boolean hasRitualItems(Player player) {
        int netherStars = 0, witherHeads = 0, echoShards = 0, totems = 0;

        for (ItemStack item : player.getInventory().getContents()) {
            if (item == null) continue;
            switch (item.getType()) {
                case NETHER_STAR -> netherStars += item.getAmount();
                case WITHER_SKELETON_SKULL -> witherHeads += item.getAmount();
                case ECHO_SHARD -> echoShards += item.getAmount();
                case TOTEM_OF_UNDYING -> totems += item.getAmount();
            }
        }

        return netherStars >= 16 && witherHeads >= 66 && echoShards >= 26 && totems >= 16;
    }

    private void consumeRitualItems(Player player) {
        removeItems(player, Material.NETHER_STAR, 16);
        removeItems(player, Material.WITHER_SKELETON_SKULL, 66);
        removeItems(player, Material.ECHO_SHARD, 26);
        removeItems(player, Material.TOTEM_OF_UNDYING, 16);
    }

    private void removeItems(Player player, Material material, int amount) {
        int toRemove = amount;
        for (ItemStack item : player.getInventory().getContents()) {
            if (item == null || item.getType() != material) continue;
            if (item.getAmount() <= toRemove) {
                toRemove -= item.getAmount();
                item.setAmount(0);
            } else {
                item.setAmount(item.getAmount() - toRemove);
                toRemove = 0;
            }
            if (toRemove == 0) break;
        }
    }

    public boolean isInRitual(Player player) {
        return ritualInProgress.contains(player.getUniqueId());
    }
}
