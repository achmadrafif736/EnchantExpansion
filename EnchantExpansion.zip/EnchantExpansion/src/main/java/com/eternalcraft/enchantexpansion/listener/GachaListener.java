package com.eternalcraft.enchantexpansion.listener;

import com.eternalcraft.enchantexpansion.EnchantExpansionPlugin;
import com.eternalcraft.enchantexpansion.enums.EnchantTier;
import com.eternalcraft.enchantexpansion.manager.EnchantManager;
import com.eternalcraft.enchantexpansion.manager.GachaManager;
import com.eternalcraft.enchantexpansion.util.PDCUtil;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.ItemStack;

public class GachaListener implements Listener {

    private final EnchantExpansionPlugin plugin;
    private final GachaManager gachaManager;
    private final EnchantManager enchantManager;

    public GachaListener(EnchantExpansionPlugin plugin, GachaManager gachaManager, EnchantManager enchantManager) {
        this.plugin = plugin;
        this.gachaManager = gachaManager;
        this.enchantManager = enchantManager;
    }

    @EventHandler
    public void onGachaClick(PlayerInteractEvent event) {
        if (event.getAction() != Action.RIGHT_CLICK_AIR && event.getAction() != Action.RIGHT_CLICK_BLOCK) return;

        ItemStack item = event.getItem();
        if (item == null) return;

        String tierStr = PDCUtil.getGachaTier(item);
        if (tierStr == null) return;

        // It's a gacha item!
        event.setCancelled(true);

        try {
            EnchantTier tier = EnchantTier.valueOf(tierStr);
            GachaManager.GachaResult result = gachaManager.openGacha(event.getPlayer(), tier);

            event.getPlayer().sendMessage(plugin.getConfig().getString("messages.prefix", "§8[§6CE§8] ") +
                    (result.success() ? "§aRate berhasil: §e" : "§cRate gagal: §e") +
                    (result.success() ? result.successRate() : result.failRate()) + "%");

            // Consume one gacha item on success
            if (result.success()) {
                item.setAmount(item.getAmount() - 1);
            }
        } catch (IllegalArgumentException e) {
            event.getPlayer().sendMessage("§cError: Tier tidak valid.");
        }
    }
}
