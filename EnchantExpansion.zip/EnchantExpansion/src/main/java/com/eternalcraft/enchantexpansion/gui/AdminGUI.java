package com.eternalcraft.enchantexpansion.gui;

import com.eternalcraft.enchantexpansion.EnchantExpansionPlugin;
import com.eternalcraft.enchantexpansion.data.CustomEnchantData;
import com.eternalcraft.enchantexpansion.enums.EnchantTier;
import com.eternalcraft.enchantexpansion.registry.EnchantRegistry;
import com.eternalcraft.enchantexpansion.util.ItemUtil;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Villager;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.jetbrains.annotations.NotNull;

import java.util.List;

public class AdminGUI implements InventoryHolder {

    private final Inventory inventory;

    public enum AdminGUIType { MAIN, ENCHANT_LIST }

    public static final String MAIN_TITLE = "§c§l[ADMIN] §6CE Item Menu";
    public static final String ENCHANT_TITLE = "§c§l[ADMIN] §6CE Enchant Books";

    public AdminGUI(EnchantExpansionPlugin plugin, AdminGUIType type) {
        if (type == AdminGUIType.MAIN) {
            this.inventory = Bukkit.createInventory(this, 27, MAIN_TITLE);
            populateMain();
        } else {
            // Calculate how many pages needed
            int enchantCount = EnchantRegistry.getAll().size();
            int size = Math.min(54, ((enchantCount / 9) + 1) * 9 + 9);
            this.inventory = Bukkit.createInventory(this, Math.min(54, size), ENCHANT_TITLE);
            populateEnchantList(0);
        }
    }

    private void populateMain() {
        // Border glass
        ItemStack glass = createGlass();
        for (int i = 0; i < 27; i++) inventory.setItem(i, glass);

        // Gacha items
        inventory.setItem(0, ItemUtil.createGachaItem(EnchantTier.NORMAL));
        inventory.setItem(1, ItemUtil.createGachaItem(EnchantTier.GOOD));
        inventory.setItem(2, ItemUtil.createGachaItem(EnchantTier.ELITE));
        inventory.setItem(3, ItemUtil.createGachaItem(EnchantTier.DIVINE));
        inventory.setItem(4, ItemUtil.createGachaItem(EnchantTier.ULTIMATE));
        inventory.setItem(5, ItemUtil.createGachaItem(EnchantTier.GOD));
        inventory.setItem(6, ItemUtil.createGachaItem(EnchantTier.SPECIAL));
        inventory.setItem(7, ItemUtil.createGachaItem(EnchantTier.SECRET));

        // Enchant books button
        ItemStack enchantBtn = new ItemStack(Material.ENCHANTED_BOOK);
        ItemMeta meta = enchantBtn.getItemMeta();
        meta.setDisplayName("§e§lBuku Enchant");
        meta.setLore(List.of("§7Klik untuk membuka daftar semua enchant book.", "§8(untuk keperluan admin/testing)"));
        enchantBtn.setItemMeta(meta);
        inventory.setItem(9, enchantBtn);

        // Spawn shop villager button
        ItemStack villagerSpawn = new ItemStack(Material.VILLAGER_SPAWN_EGG);
        ItemMeta vmeta = villagerSpawn.getItemMeta();
        vmeta.setDisplayName("§a§lSpawn Shop Villager");
        vmeta.setLore(List.of("§7Klik untuk spawn villager toko", "§7di lokasi kamu."));
        villagerSpawn.setItemMeta(vmeta);
        inventory.setItem(18, villagerSpawn);
    }

    private void populateEnchantList(int page) {
        ItemStack glass = createGlass();
        for (int i = 0; i < inventory.getSize(); i++) inventory.setItem(i, glass);

        List<CustomEnchantData> allEnchants = new java.util.ArrayList<>(EnchantRegistry.getAll().values());
        int start = page * 45;
        int slot = 0;

        for (int i = start; i < Math.min(start + 45, allEnchants.size()); i++) {
            inventory.setItem(slot, ItemUtil.createEnchantBook(allEnchants.get(i)));
            slot++;
        }
    }

    private ItemStack createGlass() {
        ItemStack glass = new ItemStack(Material.BLACK_STAINED_GLASS_PANE);
        ItemMeta m = glass.getItemMeta();
        m.setDisplayName("§r");
        glass.setItemMeta(m);
        return glass;
    }

    public static boolean isGachaSlot(int slot) {
        return slot >= 0 && slot <= 7;
    }

    public static boolean isEnchantBookButton(int slot) {
        return slot == 9;
    }

    public static boolean isVillagerSpawnButton(int slot) {
        return slot == 18;
    }

    public static boolean isEnchantBookSlot(int slot) {
        return slot >= 0 && slot <= 44;
    }

    @NotNull
    @Override
    public Inventory getInventory() {
        return inventory;
    }
}
