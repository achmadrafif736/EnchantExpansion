package com.eternalcraft.enchantexpansion.data;

import com.eternalcraft.enchantexpansion.enums.ActiveKey;
import com.eternalcraft.enchantexpansion.enums.EnchantTier;
import org.bukkit.Material;

import java.util.List;
import java.util.Set;

public class CustomEnchantData {

    private final String id;
    private final String displayName;
    private final EnchantTier tier;
    private final Set<Material> applicableItems;
    private final List<String> description;
    private final boolean isActive;
    private final ActiveKey activeKey;
    private final boolean requiresEmptyHand; // for chestplate actives
    private final long cooldownTicks;
    private final String conflictGroup; // enchants in same group can't coexist on same item

    public CustomEnchantData(String id, String displayName, EnchantTier tier,
                              Set<Material> applicableItems, List<String> description,
                              boolean isActive, ActiveKey activeKey,
                              boolean requiresEmptyHand, long cooldownTicks, String conflictGroup) {
        this.id = id;
        this.displayName = displayName;
        this.tier = tier;
        this.applicableItems = applicableItems;
        this.description = description;
        this.isActive = isActive;
        this.activeKey = activeKey;
        this.requiresEmptyHand = requiresEmptyHand;
        this.cooldownTicks = cooldownTicks;
        this.conflictGroup = conflictGroup;
    }

    public String getId() { return id; }
    public String getDisplayName() { return displayName; }
    public EnchantTier getTier() { return tier; }
    public Set<Material> getApplicableItems() { return applicableItems; }
    public List<String> getDescription() { return description; }
    public boolean isActive() { return isActive; }
    public ActiveKey getActiveKey() { return activeKey; }
    public boolean isRequiresEmptyHand() { return requiresEmptyHand; }
    public long getCooldownTicks() { return cooldownTicks; }
    public String getConflictGroup() { return conflictGroup; }

    public String getFormattedName() {
        return tier.getColorCode() + displayName;
    }

    public List<String> getFormattedLore() {
        String color = tier.getColorCode();
        List<String> lore = new java.util.ArrayList<>();
        lore.add("§8Tier: " + tier.getColoredName());
        for (String line : description) {
            lore.add("§7" + line);
        }
        if (isActive) {
            lore.add("§eAktif: §f" + activeKey.getDisplayName());
            if (requiresEmptyHand) {
                lore.add("§c(Tangan harus kosong)");
            }
            if (cooldownTicks > 0) {
                lore.add("§bCooldown: §f" + (cooldownTicks / 20) + " detik");
            }
        } else {
            lore.add("§aPassif");
        }
        return lore;
    }
}
