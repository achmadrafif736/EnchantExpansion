package com.eternalcraft.enchantexpansion.manager;

import com.eternalcraft.enchantexpansion.EnchantExpansionPlugin;
import com.eternalcraft.enchantexpansion.data.CustomEnchantData;
import com.eternalcraft.enchantexpansion.enums.EnchantTier;
import com.eternalcraft.enchantexpansion.registry.EnchantRegistry;
import com.eternalcraft.enchantexpansion.util.ItemUtil;
import com.eternalcraft.enchantexpansion.util.PDCUtil;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

import java.util.List;

public class EnchantManager {

    private final EnchantExpansionPlugin plugin;

    // Enchants that are mutually exclusive (only highest applies)
    private static final List<String> MINING_AREA_HIERARCHY = List.of(
            "deep_miner", "super_miner", "mega_miner", "infinity_miner");

    public enum ApplyResult {
        SUCCESS, WRONG_ITEM, MAX_ENCHANTS, MAX_TIER, KEY_CONFLICT, ALREADY_HAS, TIER_DOWNGRADE
    }

    public EnchantManager(EnchantExpansionPlugin plugin) {
        this.plugin = plugin;
    }

    public ApplyResult tryApply(ItemStack target, String enchantId, Player player) {
        CustomEnchantData enchant = EnchantRegistry.get(enchantId);
        if (enchant == null) return ApplyResult.WRONG_ITEM;

        // Check item type
        if (!enchant.getApplicableItems().contains(target.getType())) {
            return ApplyResult.WRONG_ITEM;
        }

        List<String> current = PDCUtil.getEnchants(target);

        // Check already has this enchant
        if (current.contains(enchantId)) return ApplyResult.ALREADY_HAS;

        // Handle mining area hierarchy
        if ("mining_area".equals(enchant.getConflictGroup())) {
            return handleMiningAreaEnchant(target, enchant, current);
        }

        // Check max enchants
        int maxTotal = plugin.getConfig().getInt("max-total-enchants", 8);
        if (current.size() >= maxTotal) return ApplyResult.MAX_ENCHANTS;

        // Check max ultimate/god per item
        if (enchant.getTier() == EnchantTier.ULTIMATE || enchant.getTier() == EnchantTier.GOD) {
            int maxTierCount = plugin.getConfig().getInt("max-ultimate-god-per-item", 2);
            long count = current.stream().map(EnchantRegistry::get)
                    .filter(e -> e != null && (e.getTier() == EnchantTier.ULTIMATE || e.getTier() == EnchantTier.GOD))
                    .count();
            if (count >= maxTierCount) return ApplyResult.MAX_TIER;
        }

        // Check max secret per item
        if (enchant.getTier() == EnchantTier.SECRET) {
            int maxSecret = plugin.getConfig().getInt("max-secret-per-item", 1);
            long count = current.stream().map(EnchantRegistry::get)
                    .filter(e -> e != null && e.getTier() == EnchantTier.SECRET)
                    .count();
            if (count >= maxSecret) return ApplyResult.MAX_TIER;
        }

        // Check active key conflict (same item + same active key)
        if (enchant.isActive() && enchant.getConflictGroup() != null) {
            for (String existingId : current) {
                CustomEnchantData existing = EnchantRegistry.get(existingId);
                if (existing != null && existing.isActive()
                        && enchant.getConflictGroup().equals(existing.getConflictGroup())) {
                    return ApplyResult.KEY_CONFLICT;
                }
            }
        }

        // Apply!
        ItemUtil.applyEnchantToItem(target, enchant);
        return ApplyResult.SUCCESS;
    }

    private ApplyResult handleMiningAreaEnchant(ItemStack target, CustomEnchantData enchant, List<String> current) {
        int newIndex = MINING_AREA_HIERARCHY.indexOf(enchant.getId());

        // Check if there's an existing mining area enchant
        String existingMiningId = null;
        for (String id : current) {
            if (MINING_AREA_HIERARCHY.contains(id)) {
                existingMiningId = id;
                break;
            }
        }

        if (existingMiningId != null) {
            int existingIndex = MINING_AREA_HIERARCHY.indexOf(existingMiningId);
            if (newIndex > existingIndex) {
                // Remove lower tier, add higher tier
                current.remove(existingMiningId);
                // Special case: infinity_miner also replaces auto_smelt
                if ("infinity_miner".equals(enchant.getId())) {
                    current.remove("auto_smelt");
                }
                PDCUtil.setEnchants(target, current);
                ItemUtil.applyEnchantToItem(target, enchant);
                return ApplyResult.SUCCESS;
            } else {
                // Can't add lower tier mining enchant when higher exists
                return ApplyResult.TIER_DOWNGRADE;
            }
        } else {
            // No existing mining area enchant, check max
            int maxTotal = plugin.getConfig().getInt("max-total-enchants", 8);
            if (current.size() >= maxTotal) return ApplyResult.MAX_ENCHANTS;
            // infinity_miner replaces auto_smelt even if no mining area enchant
            if ("infinity_miner".equals(enchant.getId()) && current.contains("auto_smelt")) {
                current.remove("auto_smelt");
                PDCUtil.setEnchants(target, current);
            }
            ItemUtil.applyEnchantToItem(target, enchant);
            return ApplyResult.SUCCESS;
        }
    }

    public void removeEnchant(ItemStack item, String enchantId) {
        ItemUtil.removeEnchantFromItem(item, enchantId);
    }

    public boolean hasEnchant(ItemStack item, String enchantId) {
        return PDCUtil.hasEnchant(item, enchantId);
    }

    public List<String> getEnchants(ItemStack item) {
        return PDCUtil.getEnchants(item);
    }

    // Check if player's armor/held item has enchant
    public boolean playerHasEnchant(Player player, String enchantId) {
        // Check held item
        if (hasEnchant(player.getInventory().getItemInMainHand(), enchantId)) return true;
        // Check armor
        for (ItemStack armor : player.getInventory().getArmorContents()) {
            if (armor != null && hasEnchant(armor, enchantId)) return true;
        }
        return false;
    }

    // Get equipped items with a specific enchant
    public java.util.List<ItemStack> getEquippedWithEnchant(Player player, String enchantId) {
        java.util.List<ItemStack> result = new java.util.ArrayList<>();
        ItemStack main = player.getInventory().getItemInMainHand();
        if (main != null && hasEnchant(main, enchantId)) result.add(main);
        for (ItemStack armor : player.getInventory().getArmorContents()) {
            if (armor != null && hasEnchant(armor, enchantId)) result.add(armor);
        }
        return result;
    }

    // Count how many armor pieces player has with a specific enchant
    public int countArmorWithEnchant(Player player, String enchantId) {
        int count = 0;
        for (ItemStack armor : player.getInventory().getArmorContents()) {
            if (armor != null && hasEnchant(armor, enchantId)) count++;
        }
        return count;
    }
}
