package com.eternalcraft.enchantexpansion;

import com.eternalcraft.enchantexpansion.command.CECommand;
import com.eternalcraft.enchantexpansion.listener.*;
import com.eternalcraft.enchantexpansion.manager.*;
import com.eternalcraft.enchantexpansion.util.PDCUtil;
import org.bukkit.plugin.java.JavaPlugin;

public class EnchantExpansionPlugin extends JavaPlugin {

    private EnchantManager enchantManager;
    private GachaManager gachaManager;
    private ActiveSkillManager activeSkillManager;
    private RitualManager ritualManager;

    @Override
    public void onEnable() {
        // Save default config
        saveDefaultConfig();

        // Init PDC keys
        PDCUtil.init(this);

        // Init managers
        enchantManager = new EnchantManager(this);
        gachaManager = new GachaManager(this);
        activeSkillManager = new ActiveSkillManager(this);
        ritualManager = new RitualManager(this);

        // Register listeners
        PassiveEnchantListener passiveListener = new PassiveEnchantListener(this, enchantManager, activeSkillManager);
        ActiveSkillListener activeListener = new ActiveSkillListener(this, enchantManager, activeSkillManager);
        ProjectileEnchantListener projectileListener = new ProjectileEnchantListener(this, enchantManager);

        // Cross-reference listeners
        passiveListener.setProjectileListener(projectileListener);
        activeListener.setProjectileListener(projectileListener);

        getServer().getPluginManager().registerEvents(passiveListener, this);
        getServer().getPluginManager().registerEvents(activeListener, this);
        getServer().getPluginManager().registerEvents(projectileListener, this);
        getServer().getPluginManager().registerEvents(new GachaListener(this, gachaManager, enchantManager), this);
        getServer().getPluginManager().registerEvents(new ShopListener(this, gachaManager, enchantManager), this);
        getServer().getPluginManager().registerEvents(new RitualListener(this, ritualManager), this);
        getServer().getPluginManager().registerEvents(new SecretAuraListener(this), this);

        // Register commands
        CECommand ceCommand = new CECommand(this);
        getCommand("ce").setExecutor(ceCommand);
        getCommand("ce").setTabCompleter(ceCommand);

        getLogger().info("═══════════════════════════════════════");
        getLogger().info("  EnchantExpansion by EternalCraft");
        getLogger().info("  All enchants loaded across 7 tiers!");
        getLogger().info("  7 tiers | Gacha System | Ritual Jiwa");
        getLogger().info("═══════════════════════════════════════");
    }

    @Override
    public void onDisable() {
        getLogger().info("EnchantExpansion disabled. Bye!");
    }

    public EnchantManager getEnchantManager() { return enchantManager; }
    public GachaManager getGachaManager() { return gachaManager; }
    public ActiveSkillManager getActiveSkillManager() { return activeSkillManager; }
    public RitualManager getRitualManager() { return ritualManager; }
}
