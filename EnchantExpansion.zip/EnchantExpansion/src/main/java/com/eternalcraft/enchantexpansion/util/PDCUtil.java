package com.eternalcraft.enchantexpansion.util;

import com.eternalcraft.enchantexpansion.EnchantExpansionPlugin;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import org.bukkit.NamespacedKey;
import org.bukkit.inventory.ItemStack;
import org.bukkit.persistence.PersistentDataContainer;
import org.bukkit.persistence.PersistentDataType;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;

public class PDCUtil {

    private static final Gson GSON = new Gson();
    private static final Type LIST_TYPE = new TypeToken<List<String>>(){}.getType();

    public static NamespacedKey ENCHANTS_KEY;
    public static NamespacedKey ENCHANT_BOOK_KEY;
    public static NamespacedKey GACHA_TIER_KEY;
    public static NamespacedKey SHOP_VILLAGER_KEY;
    public static NamespacedKey BLACK_HOLE_KEY;
    public static NamespacedKey DIVINE_INTERVENTION_COOLDOWN_KEY;

    public static void init(EnchantExpansionPlugin plugin) {
        ENCHANTS_KEY = new NamespacedKey(plugin, "custom_enchants");
        ENCHANT_BOOK_KEY = new NamespacedKey(plugin, "enchant_book");
        GACHA_TIER_KEY = new NamespacedKey(plugin, "gacha_tier");
        SHOP_VILLAGER_KEY = new NamespacedKey(plugin, "shop_villager");
        BLACK_HOLE_KEY = new NamespacedKey(plugin, "black_hole");
        DIVINE_INTERVENTION_COOLDOWN_KEY = new NamespacedKey(plugin, "di_cooldown");
    }

    public static List<String> getEnchants(ItemStack item) {
        if (item == null || !item.hasItemMeta()) return new ArrayList<>();
        PersistentDataContainer pdc = item.getItemMeta().getPersistentDataContainer();
        String json = pdc.get(ENCHANTS_KEY, PersistentDataType.STRING);
        if (json == null || json.isEmpty()) return new ArrayList<>();
        return GSON.fromJson(json, LIST_TYPE);
    }

    public static void setEnchants(ItemStack item, List<String> enchants) {
        if (item == null || !item.hasItemMeta()) return;
        var meta = item.getItemMeta();
        meta.getPersistentDataContainer().set(ENCHANTS_KEY, PersistentDataType.STRING, GSON.toJson(enchants));
        item.setItemMeta(meta);
    }

    public static boolean hasEnchant(ItemStack item, String enchantId) {
        return getEnchants(item).contains(enchantId);
    }

    public static String getEnchantBookId(ItemStack item) {
        if (item == null || !item.hasItemMeta()) return null;
        return item.getItemMeta().getPersistentDataContainer().get(ENCHANT_BOOK_KEY, PersistentDataType.STRING);
    }

    public static String getGachaTier(ItemStack item) {
        if (item == null || !item.hasItemMeta()) return null;
        return item.getItemMeta().getPersistentDataContainer().get(GACHA_TIER_KEY, PersistentDataType.STRING);
    }

    public static boolean isShopVillager(org.bukkit.entity.Entity entity) {
        if (!(entity instanceof org.bukkit.entity.Villager)) return false;
        PersistentDataContainer pdc = entity.getPersistentDataContainer();
        return pdc.has(SHOP_VILLAGER_KEY, PersistentDataType.BYTE);
    }

    public static void markShopVillager(org.bukkit.entity.Villager villager) {
        villager.getPersistentDataContainer().set(SHOP_VILLAGER_KEY, PersistentDataType.BYTE, (byte) 1);
    }
}
