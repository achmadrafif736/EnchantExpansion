package com.eternalcraft.enchantexpansion.enums;

import org.bukkit.ChatColor;
import org.bukkit.Material;

public enum EnchantTier {
    NORMAL("Normal", ChatColor.GRAY, Material.GRAY_DYE, 20, "§7"),
    GOOD("Good", ChatColor.GREEN, Material.LIME_DYE, 45, "§a"),
    ELITE("Elite", ChatColor.DARK_PURPLE, Material.PURPLE_DYE, 70, "§5"),
    DIVINE("Divine", ChatColor.BLUE, Material.BLUE_DYE, 100, "§9"),
    ULTIMATE("Ultimate", ChatColor.GOLD, Material.ORANGE_DYE, 150, "§6"),
    GOD("God", ChatColor.YELLOW, Material.YELLOW_DYE, 350, "§e"),
    SPECIAL("Special", ChatColor.DARK_RED, Material.MAGENTA_DYE, 0, "§4"),
    SECRET("Secret", ChatColor.BLACK, Material.BLACK_DYE, 0, "§0");

    private final String displayName;
    private final ChatColor color;
    private final Material dyeMaterial;
    private final int xpPrice;
    private final String colorCode;

    EnchantTier(String displayName, ChatColor color, Material dyeMaterial, int xpPrice, String colorCode) {
        this.displayName = displayName;
        this.color = color;
        this.dyeMaterial = dyeMaterial;
        this.xpPrice = xpPrice;
        this.colorCode = colorCode;
    }

    public String getDisplayName() { return displayName; }
    public ChatColor getColor() { return color; }
    public Material getDyeMaterial() { return dyeMaterial; }
    public int getXpPrice() { return xpPrice; }
    public String getColorCode() { return colorCode; }

    public String getColoredName() {
        return colorCode + displayName;
    }

    public boolean isAdminOnly() {
        return this == SPECIAL || this == SECRET;
    }
}
