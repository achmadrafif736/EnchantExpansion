package com.eternalcraft.enchantexpansion.registry;

import com.eternalcraft.enchantexpansion.data.CustomEnchantData;
import com.eternalcraft.enchantexpansion.enums.ActiveKey;
import com.eternalcraft.enchantexpansion.enums.EnchantTier;
import org.bukkit.Material;

import java.util.*;

public class EnchantRegistry {

    private static final Map<String, CustomEnchantData> enchants = new LinkedHashMap<>();

    // ==================== MATERIAL SETS ====================
    private static final Set<Material> BOOTS = Set.of(
            Material.LEATHER_BOOTS, Material.CHAINMAIL_BOOTS, Material.IRON_BOOTS,
            Material.GOLDEN_BOOTS, Material.DIAMOND_BOOTS, Material.NETHERITE_BOOTS);

    private static final Set<Material> HELMETS = Set.of(
            Material.LEATHER_HELMET, Material.CHAINMAIL_HELMET, Material.IRON_HELMET,
            Material.GOLDEN_HELMET, Material.DIAMOND_HELMET, Material.NETHERITE_HELMET,
            Material.TURTLE_HELMET);

    private static final Set<Material> CHESTPLATES = Set.of(
            Material.LEATHER_CHESTPLATE, Material.CHAINMAIL_CHESTPLATE, Material.IRON_CHESTPLATE,
            Material.GOLDEN_CHESTPLATE, Material.DIAMOND_CHESTPLATE, Material.NETHERITE_CHESTPLATE);

    private static final Set<Material> LEGGINGS = Set.of(
            Material.LEATHER_LEGGINGS, Material.CHAINMAIL_LEGGINGS, Material.IRON_LEGGINGS,
            Material.GOLDEN_LEGGINGS, Material.DIAMOND_LEGGINGS, Material.NETHERITE_LEGGINGS);

    private static final Set<Material> ALL_ARMOR;
    static {
        Set<Material> armor = new HashSet<>();
        armor.addAll(BOOTS); armor.addAll(HELMETS);
        armor.addAll(CHESTPLATES); armor.addAll(LEGGINGS);
        ALL_ARMOR = Collections.unmodifiableSet(armor);
    }

    private static final Set<Material> SWORDS = Set.of(
            Material.WOODEN_SWORD, Material.STONE_SWORD, Material.IRON_SWORD,
            Material.GOLDEN_SWORD, Material.DIAMOND_SWORD, Material.NETHERITE_SWORD);

    private static final Set<Material> AXES = Set.of(
            Material.WOODEN_AXE, Material.STONE_AXE, Material.IRON_AXE,
            Material.GOLDEN_AXE, Material.DIAMOND_AXE, Material.NETHERITE_AXE);

    private static final Set<Material> PICKAXES = Set.of(
            Material.WOODEN_PICKAXE, Material.STONE_PICKAXE, Material.IRON_PICKAXE,
            Material.GOLDEN_PICKAXE, Material.DIAMOND_PICKAXE, Material.NETHERITE_PICKAXE);

    private static final Set<Material> SHOVELS = Set.of(
            Material.WOODEN_SHOVEL, Material.STONE_SHOVEL, Material.IRON_SHOVEL,
            Material.GOLDEN_SHOVEL, Material.DIAMOND_SHOVEL, Material.NETHERITE_SHOVEL);

    private static final Set<Material> HOES = Set.of(
            Material.WOODEN_HOE, Material.STONE_HOE, Material.IRON_HOE,
            Material.GOLDEN_HOE, Material.DIAMOND_HOE, Material.NETHERITE_HOE);

    private static final Set<Material> SPEAR = Set.of(Material.TRIDENT);
    private static final Set<Material> MACE  = Set.of(Material.MACE);
    private static final Set<Material> FISHING_ROD = Set.of(Material.FISHING_ROD);
    private static final Set<Material> BOW_CROSSBOW = Set.of(Material.BOW, Material.CROSSBOW);
    private static final Set<Material> BOW_ONLY     = Set.of(Material.BOW);
    private static final Set<Material> CROSSBOW_ONLY = Set.of(Material.CROSSBOW);

    private static final Set<Material> WEAPONS;
    static {
        Set<Material> w = new HashSet<>();
        w.addAll(SWORDS); w.addAll(AXES); w.addAll(SPEAR); w.addAll(MACE);
        WEAPONS = Collections.unmodifiableSet(w);
    }

    private static final Set<Material> TOOLS;
    static {
        Set<Material> t = new HashSet<>();
        t.addAll(PICKAXES); t.addAll(SHOVELS); t.addAll(HOES); t.addAll(AXES); t.addAll(FISHING_ROD);
        TOOLS = Collections.unmodifiableSet(t);
    }

    private static final Set<Material> ALL_ITEMS;
    static {
        Set<Material> all = new HashSet<>();
        all.addAll(ALL_ARMOR); all.addAll(WEAPONS); all.addAll(TOOLS);
        ALL_ITEMS = Collections.unmodifiableSet(all);
    }

    private static final Set<Material> SWORD_AXE_SPEAR;
    static {
        Set<Material> s = new HashSet<>();
        s.addAll(SWORDS); s.addAll(AXES); s.addAll(SPEAR);
        SWORD_AXE_SPEAR = Collections.unmodifiableSet(s);
    }

    private static final Set<Material> SWORD_AXE_SPEAR_MACE;
    static {
        Set<Material> s = new HashSet<>(SWORD_AXE_SPEAR); s.addAll(MACE);
        SWORD_AXE_SPEAR_MACE = Collections.unmodifiableSet(s);
    }

    private static final Set<Material> SWORD_SPEAR;
    static {
        Set<Material> s = new HashSet<>(SWORDS); s.addAll(SPEAR);
        SWORD_SPEAR = Collections.unmodifiableSet(s);
    }

    private static final Set<Material> SWORD_AXE;
    static {
        Set<Material> s = new HashSet<>(SWORDS); s.addAll(AXES);
        SWORD_AXE = Collections.unmodifiableSet(s);
    }

    // Mining hierarchy group
    public static final List<String> MINING_HIERARCHY = List.of(
            "deep_miner", "super_miner", "mega_miner", "infinity_miner");

    // ==================== REGISTER ALL ENCHANTS ====================
    static {

        // ===== TIER NORMAL =====
        reg("lightfoot","Lightfoot",EnchantTier.NORMAL,BOOTS,List.of("Memberikan efek Speed 1 secara permanen."),false,ActiveKey.NONE,false,0,null);
        reg("sturdy","Sturdy",EnchantTier.NORMAL,ALL_ARMOR,List.of("5% peluang item tidak berkurang durabilitasnya saat dipakai."),false,ActiveKey.NONE,false,0,null);
        Set<Material> weakHungerItems = new HashSet<>(SWORD_AXE_SPEAR_MACE);
        reg("weak_hunger","Weak Hunger",EnchantTier.NORMAL,weakHungerItems,List.of("5% peluang memulihkan 1 bar lapar saat menyerang."),false,ActiveKey.NONE,false,0,null);
        reg("frog","Frog",EnchantTier.NORMAL,BOOTS,List.of("Memberikan efek Jump Boost 2 secara permanen."),false,ActiveKey.NONE,false,0,null);
        reg("zombie_hunter","Zombie Hunter",EnchantTier.NORMAL,SWORDS,List.of("Meningkatkan damage sebesar 20% kepada Zombie."),false,ActiveKey.NONE,false,0,null);
        reg("bone_lover","Bone Lover",EnchantTier.NORMAL,SWORDS,List.of("Meningkatkan damage sebesar 25% kepada Skeleton."),false,ActiveKey.NONE,false,0,null);
        reg("prank","Prank",EnchantTier.NORMAL,WEAPONS,List.of("Tidak memberikan damage apapun. Ha!"),false,ActiveKey.NONE,false,0,null);
        reg("cold","Cold",EnchantTier.NORMAL,WEAPONS,List.of("Memberikan Slowness 1 kepada musuh saat menyerang."),false,ActiveKey.NONE,false,0,null);
        reg("extra_sharp","Extra Sharp",EnchantTier.NORMAL,SWORD_AXE_SPEAR,List.of("Menambah +1.5 damage senjata."),false,ActiveKey.NONE,false,0,null);
        reg("soft_touch","Soft Touch",EnchantTier.NORMAL,BOOTS,List.of("Mengurangi fall damage sebesar 1 hati (2 poin)."),false,ActiveKey.NONE,false,0,null);
        reg("aquatic","Aquatic",EnchantTier.NORMAL,HELMETS,List.of("Menambah durasi bernapas di dalam air sebanyak 5 detik."),false,ActiveKey.NONE,false,0,null);
        reg("dull_edge","Dull Edge",EnchantTier.NORMAL,SWORD_AXE_SPEAR,List.of("Mengurangi damage senjata sebesar 1 poin. (Enchant Kutukan)"),false,ActiveKey.NONE,false,0,null);
        reg("heavy_weight","Heavy Weight",EnchantTier.NORMAL,ALL_ARMOR,List.of("Memberikan Slowness 1 tapi menambah +1 Armor Point."),false,ActiveKey.NONE,false,0,null);
        reg("fishermans_luck","Fisherman's Luck",EnchantTier.NORMAL,FISHING_ROD,List.of("10% peluang mendapatkan 2 ikan sekaligus saat memancing."),false,ActiveKey.NONE,false,0,null);
        // Proyektil Normal
        reg("hunter","Hunter",EnchantTier.NORMAL,BOW_CROSSBOW,List.of("Meningkatkan damage panah sebesar 40% kepada mob pasif."),false,ActiveKey.NONE,false,0,null);
        reg("frost_arrow","Frost Arrow",EnchantTier.NORMAL,BOW_CROSSBOW,List.of("Panah memberikan efek Slowness kepada musuh yang terkena."),false,ActiveKey.NONE,false,0,null);
        reg("super_arrow","Super Arrow",EnchantTier.NORMAL,BOW_CROSSBOW,List.of("Panah melesat lebih cepat dari biasanya."),false,ActiveKey.NONE,false,0,null);

        // ===== TIER GOOD =====
        reg("magnetize","Magnetize",EnchantTier.GOOD,PICKAXES,List.of("Item drop saat menambang otomatis terbang ke arah pemain (radius 3 blok)."),false,ActiveKey.NONE,false,0,null);
        reg("wither_hunter","Wither Hunter",EnchantTier.GOOD,SWORDS,List.of("Tambahan damage 15% kepada Wither Skeleton dan Wither Boss."),false,ActiveKey.NONE,false,0,null);
        reg("molten","Molten",EnchantTier.GOOD,ALL_ARMOR,List.of("Membakar musuh yang menyerang pemain selama 3 detik."),false,ActiveKey.NONE,false,0,null);
        reg("timber","Timber",EnchantTier.GOOD,AXES,List.of("Menghancurkan 1 log pohon akan menghancurkan 2-3 log di atasnya sekaligus."),false,ActiveKey.NONE,false,0,null);
        reg("auto_smelt","Auto-Smelt",EnchantTier.GOOD,PICKAXES,List.of("Bijih besi atau emas yang ditambang otomatis menjadi ingot."),false,ActiveKey.NONE,false,0,"mining_smelt");
        reg("farmers_grace","Farmer's Grace",EnchantTier.GOOD,HOES,List.of("Saat memanen tanaman matang, otomatis menanam kembali benihnya."),false,ActiveKey.NONE,false,0,null);
        reg("health_boost","Health Boost I",EnchantTier.GOOD,ALL_ARMOR,List.of("Menambahkan 1 darah (setengah hati) ekstra selama armor dipakai."),false,ActiveKey.NONE,false,0,null);
        reg("venom_strike","Venom Strike",EnchantTier.GOOD,WEAPONS,List.of("Memberikan efek Poison 1 selama 3 detik kepada musuh."),false,ActiveKey.NONE,false,0,null);
        reg("vampire","Vampire",EnchantTier.GOOD,WEAPONS,List.of("10% peluang memulihkan 5% darah saat membunuh mob."),false,ActiveKey.NONE,false,0,null);
        reg("night_vision","Night Vision",EnchantTier.GOOD,HELMETS,List.of("Memberikan efek Night Vision secara permanen."),false,ActiveKey.NONE,false,0,null);
        Set<Material> refinementItems = new HashSet<>(WEAPONS); refinementItems.addAll(TOOLS);
        reg("refinement","Refinement",EnchantTier.GOOD,refinementItems,List.of("Meningkatkan peluang mendapatkan lebih banyak XP dari mining/killing."),false,ActiveKey.NONE,false,0,null);
        reg("feather_fall","Feather Fall",EnchantTier.GOOD,BOOTS,List.of("Mengurangi fall damage sebesar 25%."),false,ActiveKey.NONE,false,0,null);
        // Proyektil Good
        reg("extra_power","Extra Power",EnchantTier.GOOD,BOW_CROSSBOW,List.of("Memberikan damage tambahan pada setiap panah yang ditembakkan."),false,ActiveKey.NONE,false,0,null);
        reg("poison_arrows","Poison Arrows",EnchantTier.GOOD,BOW_CROSSBOW,List.of("Panah memberikan efek Poison 1 selama 3 detik kepada musuh."),false,ActiveKey.NONE,false,0,null);

        // ===== TIER ELITE =====
        Set<Material> deepBreathItems = new HashSet<>(PICKAXES); deepBreathItems.addAll(SHOVELS);
        reg("deep_breath","Deep Breath",EnchantTier.ELITE,deepBreathItems,List.of("Meningkatkan kecepatan menambang di bawah air (Haste I di dalam air)."),false,ActiveKey.NONE,false,0,null);
        reg("adrenaline","Adrenaline",EnchantTier.ELITE,LEGGINGS,List.of("Memberikan Speed 3 selama 7 detik saat darah di bawah 25%."),false,ActiveKey.NONE,false,0,null);
        reg("regeneration_ce","Regeneration",EnchantTier.ELITE,CHESTPLATES,List.of("Memberikan Regeneration 1 secara permanen saat memakai chestplate ini."),false,ActiveKey.NONE,false,0,null);
        reg("gravity_guard","Gravity Guard",EnchantTier.ELITE,ALL_ARMOR,List.of("Mengurangi efek knockback yang diterima dari musuh sebesar 40%."),false,ActiveKey.NONE,false,0,null);
        reg("prospector","Prospector",EnchantTier.ELITE,PICKAXES,List.of("5% peluang mendapatkan Haste II selama 5 detik setelah menghancurkan Ore."),false,ActiveKey.NONE,false,0,null);
        reg("tidal_force","Tidal Force",EnchantTier.ELITE,BOOTS,List.of("Memberikan kecepatan berenang yang signifikan saat berada di dalam air."),false,ActiveKey.NONE,false,0,null);
        reg("thunder_bolt","Thunder Bolt",EnchantTier.ELITE,SWORD_SPEAR,List.of("5% peluang memanggil petir (20% saat cuaca hujan) saat menyerang."),false,ActiveKey.NONE,false,0,null);
        reg("evade","Evade",EnchantTier.ELITE,ALL_ARMOR,List.of("5% peluang untuk menghindari damage serangan musuh sepenuhnya."),false,ActiveKey.NONE,false,0,null);
        Set<Material> quickMinerItems = new HashSet<>(PICKAXES); quickMinerItems.addAll(AXES); quickMinerItems.addAll(SHOVELS);
        reg("quick_miner","Quick Miner",EnchantTier.ELITE,quickMinerItems,List.of("Memberikan efek Haste 1 secara permanen selama alat dipegang."),false,ActiveKey.NONE,false,0,null);
        reg("berserker","Berserker",EnchantTier.ELITE,SWORD_AXE,List.of("Meningkatkan damage sebesar 10% untuk setiap 2 hati yang hilang."),false,ActiveKey.NONE,false,0,null);
        reg("deep_miner","Deep Miner",EnchantTier.ELITE,PICKAXES,List.of("10% peluang menghancurkan blok 3x3 saat menambang."),false,ActiveKey.NONE,false,0,"mining_area");
        reg("ender_power","Ender Power",EnchantTier.ELITE,SWORDS,List.of("Meningkatkan damage sebesar 30% kepada Enderman dan Shulker."),false,ActiveKey.NONE,false,0,null);
        // Proyektil Elite
        reg("poseidon","Poseidon",EnchantTier.ELITE,SPEAR,List.of("Meningkatkan damage Trident secara signifikan dan memberikan efek basah."),false,ActiveKey.NONE,false,0,null);
        reg("lightning_arrow","Lightning Arrow",EnchantTier.ELITE,BOW_CROSSBOW,List.of("Memunculkan petir saat panah mengenai musuh."),false,ActiveKey.NONE,false,0,null);

        // ===== TIER DIVINE =====
        reg("thors_echo","Thor's Echo",EnchantTier.DIVINE,SWORD_AXE,List.of("30% peluang menciptakan ledakan petir area tanpa merusak blok saat menyerang."),false,ActiveKey.NONE,false,0,null);
        reg("heart_of_titan","Heart of Titan",EnchantTier.DIVINE,ALL_ARMOR,List.of("Menambah 1 darah per armor piece. Full set (4 piece) = 8 darah ekstra."),false,ActiveKey.NONE,false,0,null);
        reg("crushing","Crushing",EnchantTier.DIVINE,MACE,List.of("Semakin tinggi jatuh, semakin lama stun yang dialami musuh."),false,ActiveKey.NONE,false,0,null);
        reg("photosynthesis","Photosynthesis",EnchantTier.DIVINE,ALL_ITEMS,List.of("Item otomatis memperbaiki durabilitasnya saat pemain terkena cahaya matahari."),false,ActiveKey.NONE,false,0,null);
        reg("true_lifesteal","True Lifesteal",EnchantTier.DIVINE,WEAPONS,List.of("Setiap serangan yang mengenai musuh memulihkan 1 poin darah secara instan."),false,ActiveKey.NONE,false,0,null);
        reg("obsidian_walker","Obsidian Walker",EnchantTier.DIVINE,BOOTS,List.of("Mengubah lava di bawah kaki pemain menjadi Obsidian secara sementara."),false,ActiveKey.NONE,false,0,null);
        reg("whale_lung","Whale Lung",EnchantTier.DIVINE,HELMETS,List.of("Memberikan kemampuan bernapas di dalam air tanpa batas waktu."),false,ActiveKey.NONE,false,0,null);
        reg("spectral_edge","Spectral Edge",EnchantTier.DIVINE,WEAPONS,List.of("Serangan dapat menembus Armor musuh sebesar 50%."),false,ActiveKey.NONE,false,0,null);
        reg("hydro_power","Hydro Power",EnchantTier.DIVINE,WEAPONS,List.of("Meningkatkan damage 2x saat pemain berada di dalam air atau saat hujan."),false,ActiveKey.NONE,false,0,null);
        reg("auto_plant","Auto-Plant",EnchantTier.DIVINE,HOES,List.of("Aktif: Otomatis menanam benih dalam area 3x3x3.","Menghancurkan tanaman, area 3x3x3 ikut hancur."),true,ActiveKey.SNEAK_CLICK,false,20*5,null);
        reg("super_miner","Super Miner",EnchantTier.DIVINE,PICKAXES,List.of("Menghancurkan blok 3x3x3 saat menambang."),false,ActiveKey.NONE,false,0,"mining_area");
        // Proyektil Divine
        reg("explosion_arrow","Explosion Arrow",EnchantTier.DIVINE,BOW_CROSSBOW,List.of("Panah meledak saat mengenai musuh atau blok (tidak merusak blok)."),false,ActiveKey.NONE,false,0,null);
        reg("fire_ball","Fire Ball",EnchantTier.DIVINE,CROSSBOW_ONLY,List.of("Mengubah panah crossbow menjadi bola api kecil yang membakar musuh."),false,ActiveKey.NONE,false,0,null);
        reg("guardian_arrow","Guardian",EnchantTier.DIVINE,BOW_CROSSBOW,List.of("Panah menembus armor musuh 30% dan memberikan 2.5x damage ke mob air."),false,ActiveKey.NONE,false,0,null);

        // ===== TIER ULTIMATE =====
        reg("mega_miner","Mega Miner",EnchantTier.ULTIMATE,PICKAXES,List.of("Menghancurkan blok 5x5x5 saat menambang dan memberikan Haste 3."),false,ActiveKey.NONE,false,0,"mining_area");
        reg("iron_golem_toss","Iron Golem Toss",EnchantTier.ULTIMATE,WEAPONS,List.of("Setiap serangan melempar musuh tinggi ke udara, memberikan fall damage tambahan."),false,ActiveKey.NONE,false,0,null);
        reg("evoker_fangs","Evoker Fangs",EnchantTier.ULTIMATE,SWORDS,List.of("Memanggil rahang dari tanah dalam garis lurus ke arah musuh."),true,ActiveKey.SNEAK_CLICK,false,20*5,"sword_sneak_click");
        reg("sonic_boom","Sonic Boom",EnchantTier.ULTIMATE,CHESTPLATES,List.of("Melepaskan gelombang suara ala Warden, 50% damage Warden ke semua musuh di depan."),true,ActiveKey.SNEAK_CLICK,true,20*20,"chest_sneak_click");
        reg("life_link","Life Link",EnchantTier.ULTIMATE,ALL_ARMOR,List.of("25% dari damage yang diterima dikembalikan ke penyerang (max 75%)."),false,ActiveKey.NONE,false,0,null);
        reg("abyssal_laser","Abyssal Laser",EnchantTier.ULTIMATE,CHESTPLATES,List.of("Menembakkan laser Guardian terus-menerus (damage 1/detik). Toggle on/off."),true,ActiveKey.HOLD,true,0,"chest_hold");
        reg("wither_skull_skill","Wither Skull",EnchantTier.ULTIMATE,CHESTPLATES,List.of("Menembakkan kepala Wither yang meledak dan memberikan efek Wither II selama 5 detik."),true,ActiveKey.SNEAK_HOLD,true,20*25,"chest_sneak_hold");
        reg("dragon_breath_skill","Dragon Breath",EnchantTier.ULTIMATE,CHESTPLATES,List.of("Menyemburkan partikel naga yang memberikan damage area berkelanjutan kepada musuh di depan."),true,ActiveKey.SNEAK_CLICK,true,20*15,"chest_sneak_click");
        reg("walk_speed_override","Walk Speed Override",EnchantTier.ULTIMATE,SWORDS,List.of("Dash 20 blok ke depan. Menabrak mob: damage 3 hati, knockback, dan terbakar."),true,ActiveKey.CLICK,false,20*25,"sword_click");
        reg("auto_mlg","Auto MLG",EnchantTier.ULTIMATE,BOOTS,List.of("Saat jatuh dari ketinggian 15+ blok, air muncul otomatis saat mendarat."),false,ActiveKey.NONE,false,0,null);
        reg("anti_explosive","Anti-Explosive",EnchantTier.ULTIMATE,LEGGINGS,List.of("Kebal terhadap damage ledakan. Justru menambah darah saat terkena ledakan."),false,ActiveKey.NONE,false,0,null);
        reg("destruction_from_sky","Destruction from the Sky",EnchantTier.ULTIMATE,MACE,List.of("Terlempar ke udara, lalu jatuh dan menyebabkan ledakan besar (5 hati, AOE)."),true,ActiveKey.SNEAK_CLICK,false,20*50,"mace_sneak_click");
        reg("super_charge","Super Charge",EnchantTier.ULTIMATE,SWORDS,List.of("Tahan 2 detik lalu bergerak maju dengan kecepatan sangat tinggi dan menusuk (damage 6)."),true,ActiveKey.HOLD,false,20*15,"sword_hold");
        // Proyektil Ultimate
        reg("arrow_rain","Arrow Rain",EnchantTier.ULTIMATE,BOW_CROSSBOW,List.of("Tembak panah ke atas → hujan panah dari langit!","Bisa dikombinasikan dengan Explosion Arrow."),true,ActiveKey.SNEAK_HOLD,false,20*20,"bow_sneak_hold");
        reg("homing","Homing",EnchantTier.ULTIMATE,BOW_ONLY,List.of("Panah secara otomatis mengejar musuh terdekat dalam jangkauan."),false,ActiveKey.NONE,false,0,null);
        reg("water_explosion","Water Explosion",EnchantTier.ULTIMATE,SPEAR,List.of("Trident yang mengenai musuh atau blok menciptakan ledakan air besar.","Tidak bisa digabung dengan Riptide."),false,ActiveKey.NONE,false,0,"trident_water");

        // ===== TIER GOD =====
        reg("rasengan","Rasengan",EnchantTier.GOD,CHESTPLATES,List.of("Bola energi angin berputar. Saat mengenai musuh: 15-20 damage, knockback 20 blok."),true,ActiveKey.SNEAK_CLICK,true,20*30,"chest_sneak_click");
        reg("kamehameha","Kamehameha",EnchantTier.GOD,CHESTPLATES,List.of("Kumpulkan energi 2 detik lalu tembakkan laser biru yang memberikan 15/detik damage."),true,ActiveKey.HOLD,true,20*40,"chest_hold");
        reg("void_guard","Void Guard",EnchantTier.GOD,ALL_ARMOR,List.of("Kebal total terhadap damage Void. Jika jatuh ke Void, teleport ke permukaan aman."),false,ActiveKey.NONE,false,0,null);
        reg("infinity_miner","Infinity Miner",EnchantTier.GOD,PICKAXES,List.of("Mining 7x7x7, Haste 4. Semua ore otomatis melebur. Auto-Smelt juga aktif."),false,ActiveKey.NONE,false,0,"mining_area");
        reg("divine_intervention","Divine Intervention",EnchantTier.GOD,CHESTPLATES,List.of("Saat HP mencapai 0, darah langsung penuh dan mendapat Resistance V 10 detik.","(Cooldown: 10 menit)"),false,ActiveKey.NONE,false,20*600,null);
        Set<Material> infinityHoleItems = new HashSet<>(CHESTPLATES); infinityHoleItems.addAll(SWORDS);
        reg("infinity_hole","Infinity Hole",EnchantTier.GOD,infinityHoleItems,List.of("Menciptakan Black Hole yang menarik semua mob dalam radius 15 blok,","memberikan damage berkelanjutan, diakhiri ledakan besar."),true,ActiveKey.SNEAK_CLICK,true,20*60,"chest_sneak_click");
        reg("mayfly","Mayfly",EnchantTier.GOD,LEGGINGS,List.of("Bisa terbang seperti mode Creative selama legging dipakai."),false,ActiveKey.NONE,false,0,null);

        // ===== TIER SPECIAL =====
        reg("demonic_takaz","Demonic Takaz",EnchantTier.SPECIAL,CHESTPLATES,
                List.of(
                        "§4§lItem Admin Khusus — Tidak bisa didapat dari gacha.",
                        "Pasif: Aura api biru-merah mengelilingi pemain.",
                        "Aura memberikan Wither I + Fire selama 2 detik ke musuh yang mendekat.",
                        "Pemain mendapat Resistance I dan Fire Resistance permanen.",
                        "Aktif (Sneak+Klik, tangan kosong): §cDemonic Burst§7",
                        "  → Melepaskan ledakan api biru-merah ke semua arah (damage 10, bakar 5 detik).",
                        "  Cooldown: 20 detik."),
                true,ActiveKey.SNEAK_CLICK,true,20*20,"chest_sneak_click");

        // ===== TIER SECRET =====
        reg("wither_storm","Wither Storm",EnchantTier.SECRET,CHESTPLATES,
                List.of(
                        "§4§lJiwa Wither Storm berdiam di sini...",
                        "§8\"Kegelapan menelan segalanya.\"",
                        "Pasif 1 — Boss Health: +20 HP (10 hati) ekstra permanen.",
                        "Pasif 2 — Wither Aura: radius 5 blok, musuh/penyerang terkena Wither II.",
                        "Pasif 3 — Soul Armor: mengurangi semua damage yang diterima sebesar 35%.",
                        "Aktif 1 (Sneak+Tahan, tangan kosong): §5Wither Storm Laser",
                        "  → Laser ungu menarik semua entitas, semakin dekat semakin besar damage (max 30).",
                        "Aktif 2 (Sneak+Klik, tangan kosong): §cStorm Unleash",
                        "  → Tengkorak Wither bermuatan meledak ke segala arah.",
                        "Aktif 3 (Sneak+Lompat, tangan kosong): §4World Breaker",
                        "  → Ledakan masif radius 15 blok, damage falloff dari 40 ke 10."),
                true,ActiveKey.SNEAK_CLICK,true,0,null);

        reg("herobrine","Herobrine",EnchantTier.SECRET,CHESTPLATES,
                List.of(
                        "§8§l...Dia selalu mengawasi...",
                        "§8\"Mata tanpa jiwa, memandang dari balik kegelapan.\"",
                        "Pasif 1 — Boss Health: +20 HP (10 hati) ekstra permanen.",
                        "Pasif 2 — A Myth: Aura hitam, kabut tebal radius 50 blok.",
                        "  Sprint → Invisible + Blindness ke musuh sekitar.",
                        "Pasif 3 — Dodge: 40% menghindar dari serangan musuh.",
                        "Aktif 1 (Sneak+Klik, tangan kosong): §8Minion Summon",
                        "  → Panggil fake player (HP 40, damage 4-8) untuk menyerang musuh.",
                        "Aktif 2 (Klik, tangan kosong): §8Teleportation",
                        "  → Teleport random radius 60 blok, musuh sekitar terkena Wither II sebelum teleport.",
                        "Aktif 3 (Tahan, tangan kosong): §8Soul Reaper",
                        "  → Melesat menembus musuh, 20 damage + lifesteal penuh."),
                true,ActiveKey.SNEAK_CLICK,true,0,null);
    }

    private static void reg(String id, String name, EnchantTier tier, Set<Material> items,
                             List<String> desc, boolean active, ActiveKey key,
                             boolean requiresEmptyHand, long cooldown, String conflictGroup) {
        enchants.put(id, new CustomEnchantData(id, name, tier, items, desc, active, key, requiresEmptyHand, cooldown, conflictGroup));
    }

    public static Map<String, CustomEnchantData> getAll() { return Collections.unmodifiableMap(enchants); }
    public static CustomEnchantData get(String id) { return enchants.get(id); }
    public static List<CustomEnchantData> getByTier(EnchantTier tier) {
        List<CustomEnchantData> list = new ArrayList<>();
        for (CustomEnchantData d : enchants.values()) if (d.getTier() == tier) list.add(d);
        return list;
    }
    public static boolean exists(String id) { return enchants.containsKey(id); }
}
