package com.eternalcraft.enchantexpansion.gui;

import com.eternalcraft.enchantexpansion.EnchantExpansionPlugin;
import com.eternalcraft.enchantexpansion.enums.EnchantTier;
import com.eternalcraft.enchantexpansion.util.ItemUtil;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.jetbrains.annotations.NotNull;

import java.util.List;

public class ShopGUI implements InventoryHolder {

    private final Inventory inventory;
    private static final String TITLE = "§6✦ Enchant Gacha Shop ✦";

    public ShopGUI(EnchantExpansionPlugin plugin) {
        this.inventory = Bukkit.createInventory(this, 54, TITLE);
        populate();
    }

    private void populate() {
        // Fill borders with glass
        ItemStack glass = new ItemStack(Material.GRAY_STAINED_GLASS_PANE);
        ItemMeta glassMeta = glass.getItemMeta();
        glassMeta.setDisplayName("§r");
        glass.setItemMeta(glassMeta);

        for (int i = 0; i < 54; i++) inventory.setItem(i, glass);

        // Title info item
        ItemStack info = new ItemStack(Material.NETHER_STAR);
        ItemMeta infoMeta = info.getItemMeta();
        infoMeta.setDisplayName("§6§l✦ Enchant Gacha Shop ✦");
        infoMeta.setLore(List.of(
                "§7Klik pada gacha untuk membeli!",
                "§7Item gacha akan masuk ke inventarismu.",
                "§7Lalu klik item gacha untuk membuka enchant.",
                "",
                "§7Enchant didapat secara §erandom§7.",
                "§7Rate berhasil dan gagal bersifat §erandom§7."
        ));
        info.setItemMeta(infoMeta);
        inventory.setItem(4, info);

        // Gacha items per tier
        // Row 2: Normal, Good, Elite
        inventory.setItem(19, ItemUtil.createGachaItem(EnchantTier.NORMAL));
        inventory.setItem(22, ItemUtil.createGachaItem(EnchantTier.GOOD));
        inventory.setItem(25, ItemUtil.createGachaItem(EnchantTier.ELITE));

        // Row 3: Divine, Ultimate, God
        inventory.setItem(28, ItemUtil.createGachaItem(EnchantTier.DIVINE));
        inventory.setItem(31, ItemUtil.createGachaItem(EnchantTier.ULTIMATE));
        inventory.setItem(34, ItemUtil.createGachaItem(EnchantTier.GOD));

        // Row 4: Secret info
        ItemStack secretInfo = new ItemStack(Material.BLACK_DYE);
        ItemMeta secretMeta = secretInfo.getItemMeta();
        secretMeta.setDisplayName("§0§l✦ Secret ✦");
        secretMeta.setLore(List.of(
                "§8Tidak dapat dibeli.",
                "§4Special: Hanya dari command Admin/OP.",
                "§8Secret: Hanya dari",
                "§0§l✦ Ritual Jiwa ✦",
                "",
                "§8Bahan ritual:",
                "§716x Nether Star",
                "§766x Wither Skeleton Skull",
                "§726x Echo Shard",
                "§716x Totem of Undying",
                "§7Lakukan di §4Soul Sand Valley",
                "§7Pegang §6Gacha God §7di tangan utama"
        ));
        secretInfo.setItemMeta(secretMeta);
        inventory.setItem(40, secretInfo);
    }

    // Get which tier was clicked based on slot
    public static EnchantTier getTierFromSlot(int slot) {
        return switch (slot) {
            case 19 -> EnchantTier.NORMAL;
            case 22 -> EnchantTier.GOOD;
            case 25 -> EnchantTier.ELITE;
            case 28 -> EnchantTier.DIVINE;
            case 31 -> EnchantTier.ULTIMATE;
            case 34 -> EnchantTier.GOD;
            default -> null;
        };
    }

    @NotNull
    @Override
    public Inventory getInventory() {
        return inventory;
    }
}
