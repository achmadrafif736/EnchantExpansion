package com.eternalcraft.enchantexpansion.util;

import com.eternalcraft.enchantexpansion.data.CustomEnchantData;
import com.eternalcraft.enchantexpansion.enums.EnchantTier;
import com.eternalcraft.enchantexpansion.registry.EnchantRegistry;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.ArrayList;
import java.util.List;

public class ItemUtil {

    // ======================== GACHA ITEMS ========================

    public static ItemStack createGachaItem(EnchantTier tier) {
        ItemStack item = new ItemStack(tier.getDyeMaterial());
        ItemMeta meta = item.getItemMeta();

        String tierColor = tier.getColorCode();
        meta.setDisplayName(tierColor + "✦ Gacha " + tier.getDisplayName() + " ✦");

        List<String> lore = new ArrayList<>();
        lore.add("§7Klik untuk membuka gacha!");
        lore.add("§7Tier: " + tier.getColoredName());
        if (tier != EnchantTier.SECRET) {
            lore.add("§6Harga: §e" + tier.getXpPrice() + " XP");
        } else {
            lore.add("§0§lHanya dari Ritual Jiwa...");
        }
        lore.add("");
        lore.add("§8Rate: §71%–100% berhasil");
        lore.add("§8       §70%–99% gagal");

        if (tier == EnchantTier.SECRET) {
            lore.add("");
            lore.add("§0§l⚠ GAME BREAKER ⚠");
            lore.add("§8§oSesuatu yang tidak seharusnya ada...");
            meta.addEnchant(Enchantment.UNBREAKING, 1, true);
            meta.addItemFlags(ItemFlag.HIDE_ENCHANTS);
        }

        meta.setLore(lore);
        meta.getPersistentDataContainer().set(PDCUtil.GACHA_TIER_KEY,
                org.bukkit.persistence.PersistentDataType.STRING, tier.name());
        item.setItemMeta(meta);
        return item;
    }

    // ======================== ENCHANT BOOKS ========================

    public static ItemStack createEnchantBook(CustomEnchantData enchant) {
        ItemStack item = new ItemStack(Material.ENCHANTED_BOOK);
        ItemMeta meta = item.getItemMeta();

        String tierColor = enchant.getTier().getColorCode();
        meta.setDisplayName(tierColor + "✦ " + enchant.getDisplayName() + " ✦");

        List<String> lore = new ArrayList<>();
        lore.add("§8Tier: " + enchant.getTier().getColoredName());
        lore.add("");
        for (String line : enchant.getDescription()) {
            lore.add("§7" + line);
        }
        lore.add("");
        if (enchant.isActive()) {
            lore.add("§eAktif: §f" + enchant.getActiveKey().getDisplayName());
            if (enchant.isRequiresEmptyHand()) lore.add("§c(Tangan utama harus kosong)");
            if (enchant.getCooldownTicks() > 0) lore.add("§bCooldown: §f" + (enchant.getCooldownTicks() / 20) + "s");
        } else {
            lore.add("§aPassif");
        }
        lore.add("");
        lore.add("§8§oDrag ke item untuk memasang enchant.");

        // Items applicable
        lore.add("");
        lore.add("§7Item yang bisa dipasang:");
        StringBuilder sb = new StringBuilder("§8");
        int count = 0;
        for (org.bukkit.Material mat : enchant.getApplicableItems()) {
            if (count >= 3) { sb.append("..."); break; }
            if (count > 0) sb.append(", ");
            sb.append(formatMaterial(mat));
            count++;
        }
        lore.add(sb.toString());

        meta.addEnchant(Enchantment.UNBREAKING, 1, true);
        meta.addItemFlags(ItemFlag.HIDE_ENCHANTS, ItemFlag.HIDE_ATTRIBUTES);
        meta.setLore(lore);
        meta.getPersistentDataContainer().set(PDCUtil.ENCHANT_BOOK_KEY,
                org.bukkit.persistence.PersistentDataType.STRING, enchant.getId());
        item.setItemMeta(meta);
        return item;
    }

    // ======================== APPLY ENCHANT TO ITEM ========================

    public static void applyEnchantToItem(ItemStack item, CustomEnchantData enchant) {
        List<String> enchants = PDCUtil.getEnchants(item);
        enchants.add(enchant.getId());
        PDCUtil.setEnchants(item, enchants);
        refreshItemLore(item);
    }

    public static void removeEnchantFromItem(ItemStack item, String enchantId) {
        List<String> enchants = PDCUtil.getEnchants(item);
        enchants.remove(enchantId);
        PDCUtil.setEnchants(item, enchants);
        refreshItemLore(item);
    }

    public static void refreshItemLore(ItemStack item) {
        if (item == null || !item.hasItemMeta()) return;
        ItemMeta meta = item.getItemMeta();
        List<String> enchantIds = PDCUtil.getEnchants(item);

        // Get existing lore that doesn't belong to CE enchants (first 2 lines preserved)
        List<String> baseLore = new ArrayList<>();

        // Add all enchant descriptions
        for (String id : enchantIds) {
            CustomEnchantData data = EnchantRegistry.get(id);
            if (data == null) continue;
            String color = data.getTier().getColorCode();
            baseLore.add(color + "✦ " + data.getDisplayName() + " §8[" + data.getTier().getDisplayName() + "]");
        }

        if (!baseLore.isEmpty()) {
            meta.addEnchant(Enchantment.UNBREAKING, 1, true);
            meta.addItemFlags(ItemFlag.HIDE_ENCHANTS, ItemFlag.HIDE_ATTRIBUTES);
        }

        meta.setLore(baseLore);
        item.setItemMeta(meta);
    }

    // ======================== HELPER ========================

    private static String formatMaterial(Material material) {
        String name = material.name().toLowerCase().replace("_", " ");
        return name.substring(0, 1).toUpperCase() + name.substring(1);
    }

    public static boolean isWeapon(ItemStack item) {
        if (item == null) return false;
        Material m = item.getType();
        return m == Material.TRIDENT || m == Material.MACE ||
               m.name().endsWith("_SWORD") || m.name().endsWith("_AXE");
    }

    public static boolean isArmor(ItemStack item) {
        if (item == null) return false;
        Material m = item.getType();
        return m.name().contains("_HELMET") || m.name().contains("_CHESTPLATE") ||
               m.name().contains("_LEGGINGS") || m.name().contains("_BOOTS");
    }

    public static boolean isOre(Material material) {
        String name = material.name();
        return name.contains("_ORE") || name.equals("ANCIENT_DEBRIS");
    }

    public static Material getSmeltedResult(Material ore) {
        return switch (ore) {
            case IRON_ORE, DEEPSLATE_IRON_ORE -> Material.IRON_INGOT;
            case GOLD_ORE, DEEPSLATE_GOLD_ORE, NETHER_GOLD_ORE -> Material.GOLD_INGOT;
            case COPPER_ORE, DEEPSLATE_COPPER_ORE -> Material.COPPER_INGOT;
            case ANCIENT_DEBRIS -> Material.NETHERITE_SCRAP;
            default -> null;
        };
    }

    public static boolean isLog(Material material) {
        String name = material.name();
        return name.endsWith("_LOG") || name.endsWith("_WOOD");
    }

    public static boolean isCrop(Material material) {
        return switch (material) {
            case WHEAT, CARROTS, POTATOES, BEETROOTS, NETHER_WART -> true;
            default -> false;
        };
    }
}
