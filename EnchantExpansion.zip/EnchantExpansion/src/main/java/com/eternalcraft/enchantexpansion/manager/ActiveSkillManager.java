package com.eternalcraft.enchantexpansion.manager;

import com.eternalcraft.enchantexpansion.EnchantExpansionPlugin;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scheduler.BukkitTask;

import java.util.*;

public class ActiveSkillManager {

    private final EnchantExpansionPlugin plugin;

    // Cooldowns: player UUID -> (enchant ID -> tick when cooldown ends)
    private final Map<UUID, Map<String, Long>> cooldowns = new HashMap<>();

    // Hold state tracking (for HOLD and SNEAK_HOLD keys)
    private final Map<UUID, BukkitTask> holdTasks = new HashMap<>();
    private final Set<UUID> chargingPlayers = new HashSet<>();

    // Toggle state for continuous skills (Abyssal Laser, Kamehameha)
    private final Map<UUID, String> activeToggle = new HashMap<>();
    private final Map<UUID, BukkitTask> toggleTasks = new HashMap<>();

    // Black hole tracking
    private final Map<UUID, BukkitTask> blackHoleTasks = new HashMap<>();

    // Divine Intervention per-player cooldown
    private final Map<UUID, Long> diCooldowns = new HashMap<>();

    // Infinity Hole active entity tracking
    private final Map<UUID, org.bukkit.entity.Entity> blackHoleEntities = new HashMap<>();

    // Sneak+Jump: track players who recently sneaked in air
    private final Set<UUID> snneakJumpArmed = new HashSet<>();

    public ActiveSkillManager(EnchantExpansionPlugin plugin) {
        this.plugin = plugin;
    }

    // ======================== COOLDOWN ========================

    public boolean isOnCooldown(Player player, String enchantId) {
        Map<String, Long> pMap = cooldowns.get(player.getUniqueId());
        if (pMap == null) return false;
        Long endTick = pMap.get(enchantId);
        if (endTick == null) return false;
        return plugin.getServer().getCurrentTick() < endTick;
    }

    public long getRemainingCooldownSeconds(Player player, String enchantId) {
        Map<String, Long> pMap = cooldowns.get(player.getUniqueId());
        if (pMap == null) return 0;
        Long endTick = pMap.get(enchantId);
        if (endTick == null) return 0;
        long remaining = endTick - plugin.getServer().getCurrentTick();
        return Math.max(0, remaining / 20);
    }

    public void setCooldown(Player player, String enchantId, long durationTicks) {
        cooldowns.computeIfAbsent(player.getUniqueId(), k -> new HashMap<>())
                .put(enchantId, plugin.getServer().getCurrentTick() + durationTicks);
    }

    // ======================== HOLD / CHARGE ========================

    public void startHoldCharge(Player player, long chargeTimeTicks, Runnable onComplete) {
        UUID uuid = player.getUniqueId();
        cancelHold(player);
        chargingPlayers.add(uuid);
        BukkitTask task = new BukkitRunnable() {
            @Override
            public void run() {
                if (!player.isOnline() || !chargingPlayers.contains(uuid)) {
                    cancel();
                    return;
                }
                chargingPlayers.remove(uuid);
                holdTasks.remove(uuid);
                onComplete.run();
            }
        }.runTaskLater(plugin, chargeTimeTicks);
        holdTasks.put(uuid, task);
    }

    public boolean isCharging(Player player) {
        return chargingPlayers.contains(player.getUniqueId());
    }

    public void cancelHold(Player player) {
        UUID uuid = player.getUniqueId();
        chargingPlayers.remove(uuid);
        BukkitTask t = holdTasks.remove(uuid);
        if (t != null) t.cancel();
    }

    // ======================== TOGGLE (continuous skills) ========================

    public boolean isToggled(Player player, String enchantId) {
        return enchantId.equals(activeToggle.get(player.getUniqueId()));
    }

    public void startToggle(Player player, String enchantId, BukkitTask task) {
        stopToggle(player);
        activeToggle.put(player.getUniqueId(), enchantId);
        toggleTasks.put(player.getUniqueId(), task);
    }

    public void stopToggle(Player player) {
        UUID uuid = player.getUniqueId();
        activeToggle.remove(uuid);
        BukkitTask t = toggleTasks.remove(uuid);
        if (t != null) t.cancel();
    }

    // ======================== BLACK HOLE ========================

    public boolean hasBlackHole(Player player) {
        return blackHoleTasks.containsKey(player.getUniqueId());
    }

    public void startBlackHole(Player player, BukkitTask task) {
        endBlackHole(player);
        blackHoleTasks.put(player.getUniqueId(), task);
    }

    public void endBlackHole(Player player) {
        BukkitTask t = blackHoleTasks.remove(player.getUniqueId());
        if (t != null) t.cancel();
        blackHoleEntities.remove(player.getUniqueId());
    }

    // ======================== DIVINE INTERVENTION ========================

    public boolean isDICooldown(Player player) {
        Long endMs = diCooldowns.get(player.getUniqueId());
        if (endMs == null) return false;
        return System.currentTimeMillis() < endMs;
    }

    public long getDIRemainingSeconds(Player player) {
        Long endMs = diCooldowns.get(player.getUniqueId());
        if (endMs == null) return 0;
        return Math.max(0, (endMs - System.currentTimeMillis()) / 1000);
    }

    public void setDICooldown(Player player) {
        // 10 minute cooldown
        diCooldowns.put(player.getUniqueId(), System.currentTimeMillis() + 600_000L);
    }

    // ======================== SNEAK+JUMP ARM ========================

    public void armSneakJump(Player player) {
        snneakJumpArmed.add(player.getUniqueId());
        // Auto-disarm after 1 second if not used
        new BukkitRunnable() {
            @Override
            public void run() { snneakJumpArmed.remove(player.getUniqueId()); }
        }.runTaskLater(plugin, 20L);
    }

    public boolean consumeSneakJump(Player player) {
        return snneakJumpArmed.remove(player.getUniqueId());
    }

    // ======================== CLEANUP ========================

    public void cleanup(Player player) {
        UUID uuid = player.getUniqueId();
        cooldowns.remove(uuid);
        cancelHold(player);
        stopToggle(player);
        endBlackHole(player);
        diCooldowns.remove(uuid);
        snneakJumpArmed.remove(uuid);
    }
}
