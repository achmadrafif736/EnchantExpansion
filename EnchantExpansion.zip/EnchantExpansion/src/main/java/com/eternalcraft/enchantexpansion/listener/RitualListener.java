package com.eternalcraft.enchantexpansion.listener;

import com.eternalcraft.enchantexpansion.EnchantExpansionPlugin;
import com.eternalcraft.enchantexpansion.manager.RitualManager;
import com.eternalcraft.enchantexpansion.util.PDCUtil;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.ItemStack;

public class RitualListener implements Listener {

    private final EnchantExpansionPlugin plugin;
    private final RitualManager ritualManager;

    public RitualListener(EnchantExpansionPlugin plugin, RitualManager ritualManager) {
        this.plugin = plugin;
        this.ritualManager = ritualManager;
    }

    @EventHandler
    public void onRitualInteract(PlayerInteractEvent event) {
        if (event.getAction() != Action.RIGHT_CLICK_AIR && event.getAction() != Action.RIGHT_CLICK_BLOCK) return;

        ItemStack item = event.getItem();
        if (item == null) return;

        // Check if holding GOD gacha while sneaking
        if (!event.getPlayer().isSneaking()) return;
        String tier = PDCUtil.getGachaTier(item);
        if (!"GOD".equals(tier)) return;

        // Attempt ritual
        event.setCancelled(true);
        RitualManager.RitualResult result = ritualManager.startRitual(event.getPlayer());

        String prefix = plugin.getConfig().getString("messages.prefix", "§8[§6CE§8] ");
        switch (result) {
            case SUCCESS -> {} // Messages handled in RitualManager
            case WRONG_BIOME -> event.getPlayer().sendMessage(prefix + "§cRitual hanya bisa dilakukan di §4Soul Sand Valley§c!");
            case MISSING_ITEMS -> {
                event.getPlayer().sendMessage(prefix + "§cBahan ritual tidak lengkap! Butuh di inventaris:");
                event.getPlayer().sendMessage("§716x §aNether Star");
                event.getPlayer().sendMessage("§766x §aWither Skeleton Skull");
                event.getPlayer().sendMessage("§726x §aEcho Shard");
                event.getPlayer().sendMessage("§716x §aTotem of Undying");
            }
            case WRONG_HAND -> event.getPlayer().sendMessage(prefix + "§cPerlu memegang §6Gacha God §cdi tangan utama!");
            case ALREADY_IN_PROGRESS -> event.getPlayer().sendMessage(prefix + "§cRitual sedang berlangsung!");
        }
    }
}
