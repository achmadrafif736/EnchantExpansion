package com.eternalcraft.enchantexpansion.listener;

import com.eternalcraft.enchantexpansion.EnchantExpansionPlugin;
import com.eternalcraft.enchantexpansion.manager.ActiveSkillManager;
import com.eternalcraft.enchantexpansion.manager.EnchantManager;
import com.eternalcraft.enchantexpansion.util.ItemUtil;
import com.eternalcraft.enchantexpansion.util.PDCUtil;
import org.bukkit.*;
import org.bukkit.block.Block;
import org.bukkit.block.BlockFace;
import org.bukkit.block.data.Ageable;
import org.bukkit.entity.*;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.entity.*;
import org.bukkit.event.inventory.InventoryPickupItemEvent;
import org.bukkit.event.player.*;
import org.bukkit.inventory.ItemStack;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.Vector;

import java.util.*;

public class PassiveEnchantListener implements Listener {

    private final EnchantExpansionPlugin plugin;
    private final EnchantManager em;
    private final ActiveSkillManager asm;
    private final Random random = new Random();

    // Track players with adrenaline recently triggered (to avoid spam)
    private final Set<UUID> adrenalineTriggered = new HashSet<>();
    // Track fall distance for crushing & auto-mlg
    private final Map<UUID, Double> fallStartY = new HashMap<>();
    // Track obsidian blocks placed by obsidian walker (for cleanup)
    private final Map<Location, Long> tempObsidian = new HashMap<>();
    // Track players with divine intervention already saved
    private final Set<UUID> diSaved = new HashSet<>();
    // Track heart of titan bonus
    private final Map<UUID, Integer> hotBonusHearts = new HashMap<>();

    public PassiveEnchantListener(EnchantExpansionPlugin plugin, EnchantManager em, ActiveSkillManager asm) {
        this.plugin = plugin;
        this.em = em;
        this.asm = asm;

        // Start repeating task for permanent effects and cleanup
        new BukkitRunnable() {
            @Override
            public void run() {
                tickPermanentEffects();
                cleanupTempObsidian();
            }
        }.runTaskTimer(plugin, 20L, 20L); // Every second

        // Photosynthesis repair (faster - every 2 ticks)
        new BukkitRunnable() {
            @Override
            public void run() {
                tickPhotosynthesis();
            }
        }.runTaskTimer(plugin, 20L, 2L);
    }

    // ======================== PERMANENT EFFECTS TICK ========================

    private void tickPermanentEffects() {
        for (Player player : Bukkit.getOnlinePlayers()) {
            applyPermEffects(player);
            tickHeartOfTitan(player);
            tickMayfly(player);
            tickVoidGuard(player);
            tickObsidianWalker(player);
            tickTidalForce(player);
            tickDeepBreath(player);
            tickHydroInWater(player);
            tickAutoMLGCheck(player);
            tickSecretSpecialPassives(player);
        }
    }

    private void applyPermEffects(Player player) {
        boolean hasLightfoot = false, hasFrog = false, hasNightVision = false,
                hasQuickMiner = false, hasRegen = false, hasHeavyWeight = false,
                hasAquatic = false, hasWhaleLung = false;

        // Check armor
        for (ItemStack armor : player.getInventory().getArmorContents()) {
            if (armor == null) continue;
            if (em.hasEnchant(armor, "lightfoot")) hasLightfoot = true;
            if (em.hasEnchant(armor, "frog")) hasFrog = true;
            if (em.hasEnchant(armor, "night_vision")) hasNightVision = true;
            if (em.hasEnchant(armor, "regeneration_ce")) hasRegen = true;
            if (em.hasEnchant(armor, "heavy_weight")) hasHeavyWeight = true;
            if (em.hasEnchant(armor, "aquatic")) hasAquatic = true;
            if (em.hasEnchant(armor, "whale_lung")) hasWhaleLung = true;
        }

        // Check held items
        ItemStack held = player.getInventory().getItemInMainHand();
        if (em.hasEnchant(held, "quick_miner")) hasQuickMiner = true;

        // Apply effects
        int duration = 60; // 3 seconds, applied every second = always active
        if (hasLightfoot) player.addPotionEffect(new PotionEffect(PotionEffectType.SPEED, duration, 0, true, false, true));
        if (hasFrog) player.addPotionEffect(new PotionEffect(PotionEffectType.JUMP_BOOST, duration, 1, true, false, true));
        if (hasNightVision) player.addPotionEffect(new PotionEffect(PotionEffectType.NIGHT_VISION, 400, 0, true, false, false));
        if (hasRegen) player.addPotionEffect(new PotionEffect(PotionEffectType.REGENERATION, duration, 0, true, false, true));
        if (hasHeavyWeight) {
            player.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS, duration, 0, true, false, true));
            // +1 armor is handled via attribute if needed; simplified: just apply effect
        }
        if (hasAquatic && player.isInWater()) {
            player.setRemainingAir(Math.min(player.getMaximumAir(), player.getRemainingAir() + 100));
        }
        if (hasWhaleLung) {
            player.setRemainingAir(player.getMaximumAir());
        }
        if (hasQuickMiner) player.addPotionEffect(new PotionEffect(PotionEffectType.HASTE, duration, 0, true, false, true));

        // Mega Miner: Haste 3 while holding pickaxe
        if (em.hasEnchant(held, "mega_miner")) {
            player.addPotionEffect(new PotionEffect(PotionEffectType.HASTE, duration, 2, true, false, true));
        }
        // Infinity Miner: Haste 4
        if (em.hasEnchant(held, "infinity_miner")) {
            player.addPotionEffect(new PotionEffect(PotionEffectType.HASTE, duration, 3, true, false, true));
        }
    }

    private void tickHeartOfTitan(Player player) {
        int count = em.countArmorWithEnchant(player, "heart_of_titan");
        int bonusHearts = count * 1; // 1 heart per armor piece (up to 4 = 4 hearts... but spec says full set = 8 darah)
        // Spec: 1 piece = 2 darah (1 heart), full set (4 pieces) = 8 darah (4 hearts)
        // So it's 2 health per piece
        int bonusHealth = count * 2;
        int currentBonus = hotBonusHearts.getOrDefault(player.getUniqueId(), 0);
        if (bonusHealth != currentBonus) {
            // Adjust max health
            var attr = player.getAttribute(org.bukkit.attribute.Attribute.MAX_HEALTH);
            if (attr != null) {
                double baseMax = attr.getBaseValue();
                double newMax = 20.0 + bonusHealth;
                attr.setBaseValue(newMax);
                if (player.getHealth() > newMax) player.setHealth(newMax);
            }
            hotBonusHearts.put(player.getUniqueId(), bonusHealth);
        }
    }

    private void tickMayfly(Player player) {
        boolean hasMayfly = false;
        ItemStack[] armor = player.getInventory().getArmorContents();
        if (armor[1] != null && em.hasEnchant(armor[1], "mayfly")) hasMayfly = true; // leggings slot is index 1

        if (hasMayfly) {
            player.setAllowFlight(true);
        } else {
            if (player.getAllowFlight() && player.getGameMode() == GameMode.SURVIVAL) {
                player.setAllowFlight(false);
                player.setFlying(false);
            }
        }
    }

    private void tickVoidGuard(Player player) {
        boolean hasVoidGuard = false;
        for (ItemStack armor : player.getInventory().getArmorContents()) {
            if (armor != null && em.hasEnchant(armor, "void_guard")) { hasVoidGuard = true; break; }
        }

        if (hasVoidGuard && player.getLocation().getY() < -70) {
            // Find safe location above
            Location safe = player.getWorld().getHighestBlockAt(player.getLocation()).getLocation().add(0, 1, 0);
            player.teleport(safe);
            player.sendMessage("§b§lVoid Guard §7mengangkatmu kembali ke permukaan!");
            player.addPotionEffect(new PotionEffect(PotionEffectType.ABSORPTION, 100, 3, true, true));
        }
    }

    private void tickObsidianWalker(Player player) {
        ItemStack[] boots = player.getInventory().getArmorContents();
        if (boots[0] == null || !em.hasEnchant(boots[0], "obsidian_walker")) return;

        Location below = player.getLocation().subtract(0, 1, 0);
        if (below.getBlock().getType() == Material.LAVA) {
            below.getBlock().setType(Material.OBSIDIAN);
            tempObsidian.put(below, System.currentTimeMillis() + 3000); // 3 sec
        }
        // Also check 2 blocks below
        Location below2 = player.getLocation().subtract(0, 0.5, 0);
        if (below2.getBlock().getType() == Material.LAVA) {
            below2.getBlock().setType(Material.OBSIDIAN);
            tempObsidian.put(below2, System.currentTimeMillis() + 3000);
        }
    }

    private void cleanupTempObsidian() {
        long now = System.currentTimeMillis();
        Iterator<Map.Entry<Location, Long>> iter = tempObsidian.entrySet().iterator();
        while (iter.hasNext()) {
            var entry = iter.next();
            if (now > entry.getValue()) {
                if (entry.getKey().getBlock().getType() == Material.OBSIDIAN) {
                    entry.getKey().getBlock().setType(Material.AIR);
                }
                iter.remove();
            }
        }
    }

    private void tickTidalForce(Player player) {
        ItemStack[] boots = player.getInventory().getArmorContents();
        if (boots[0] == null || !em.hasEnchant(boots[0], "tidal_force")) return;
        if (player.isInWater()) {
            player.addPotionEffect(new PotionEffect(PotionEffectType.DOLPHINS_GRACE, 60, 2, true, false, false));
            player.addPotionEffect(new PotionEffect(PotionEffectType.SPEED, 60, 1, true, false, false));
        }
    }

    private void tickDeepBreath(Player player) {
        ItemStack held = player.getInventory().getItemInMainHand();
        if (!em.hasEnchant(held, "deep_breath")) return;
        if (player.isInWater()) {
            player.addPotionEffect(new PotionEffect(PotionEffectType.HASTE, 60, 1, true, false, false));
        }
    }

    private void tickHydroInWater(Player player) {
        // Hydro Power applies during EntityDamageByEntityEvent, but we track state here
    }

    private void tickAutoMLGCheck(Player player) {
        if (player.isOnGround()) {
            fallStartY.remove(player.getUniqueId());
        } else if (!fallStartY.containsKey(player.getUniqueId())) {
            fallStartY.put(player.getUniqueId(), player.getLocation().getY());
        }
    }

    private void tickPhotosynthesis() {
        for (Player player : Bukkit.getOnlinePlayers()) {
            if (!player.getWorld().hasStorm() && player.getEyeLocation().getBlock().getLightFromSky() >= 14) {
                repairItemPhotosynthesis(player.getInventory().getItemInMainHand(), player);
                repairItemPhotosynthesis(player.getInventory().getItemInOffHand(), player);
                for (ItemStack armor : player.getInventory().getArmorContents()) {
                    repairItemPhotosynthesis(armor, player);
                }
            }
        }
    }

    private void repairItemPhotosynthesis(ItemStack item, Player player) {
        if (item == null || !item.hasItemMeta() || !em.hasEnchant(item, "photosynthesis")) return;
        if (item.getType().getMaxDurability() > 0) {
            short dur = item.getDurability();
            if (dur > 0) item.setDurability((short) Math.max(0, dur - 5));
        }
    }

    // ======================== ATTACK EVENTS ========================

    @EventHandler(priority = EventPriority.NORMAL)
    public void onAttack(EntityDamageByEntityEvent event) {
        if (!(event.getDamager() instanceof Player player)) return;
        if (!(event.getEntity() instanceof LivingEntity target)) return;

        ItemStack weapon = player.getInventory().getItemInMainHand();
        double damage = event.getDamage();

        // Prank: zero damage
        if (em.hasEnchant(weapon, "prank")) {
            event.setDamage(0);
            player.sendMessage("§eHahaha! Serangan Prank tidak memberikan damage!");
            return;
        }

        // Dull Edge: -1 damage
        if (em.hasEnchant(weapon, "dull_edge")) {
            damage = Math.max(0, damage - 1);
            event.setDamage(damage);
        }

        // Extra Sharp: +1.5 damage
        if (em.hasEnchant(weapon, "extra_sharp")) {
            damage += 1.5;
            event.setDamage(damage);
        }

        // Zombie Hunter: +20% to zombies
        if (em.hasEnchant(weapon, "zombie_hunter") && isZombie(target)) {
            damage *= 1.2;
            event.setDamage(damage);
        }

        // Bone Lover: +25% to skeletons
        if (em.hasEnchant(weapon, "bone_lover") && isSkeleton(target)) {
            damage *= 1.25;
            event.setDamage(damage);
        }

        // Wither Hunter: +15% to wither mobs
        if (em.hasEnchant(weapon, "wither_hunter") && isWitherMob(target)) {
            damage *= 1.15;
            event.setDamage(damage);
        }

        // Ender Power: +30% to endermen and shulkers
        if (em.hasEnchant(weapon, "ender_power") && isEnderMob(target)) {
            damage *= 1.30;
            event.setDamage(damage);
        }

        // Berserker: +10% per 2 hearts missing
        if (em.hasEnchant(weapon, "berserker")) {
            double missingHealth = player.getAttribute(org.bukkit.attribute.Attribute.MAX_HEALTH).getValue() - player.getHealth();
            int heartsLost = (int) (missingHealth / 2);
            double bonus = 1 + (heartsLost * 0.10);
            damage *= bonus;
            event.setDamage(damage);
        }

        // Hydro Power: 2x if in water or rain
        if (em.hasEnchant(weapon, "hydro_power")) {
            if (player.isInWater() || player.getWorld().hasStorm()) {
                damage *= 2.0;
                event.setDamage(damage);
            }
        }

        // Spectral Edge: 50% armor penetration (reduce target armor by 50%)
        if (em.hasEnchant(weapon, "spectral_edge")) {
            if (target instanceof Player targetPlayer) {
                var armorAttr = targetPlayer.getAttribute(org.bukkit.attribute.Attribute.ARMOR);
                if (armorAttr != null) {
                    // Simulate 50% armor pierce by amplifying damage slightly
                    // This is approximated as +30% damage to simulate armor bypass
                    damage *= 1.30;
                    event.setDamage(damage);
                }
            }
        }

        // Cold: Slowness 1 to enemy
        if (em.hasEnchant(weapon, "cold")) {
            target.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS, 60, 0, true, true));
        }

        // Venom Strike: Poison 1 for 3s
        if (em.hasEnchant(weapon, "venom_strike")) {
            target.addPotionEffect(new PotionEffect(PotionEffectType.POISON, 60, 0, true, true));
        }

        // Thunder Bolt: 5% (20% in rain) chance lightning
        if (em.hasEnchant(weapon, "thunder_bolt")) {
            double chance = player.getWorld().hasStorm() ? 0.20 : 0.05;
            if (random.nextDouble() < chance) {
                target.getWorld().strikeLightningEffect(target.getLocation());
                target.getWorld().spawnParticle(Particle.FLASH, target.getLocation(), 3);
            }
        }

        // Thor's Echo: 30% lightning area (no block damage)
        if (em.hasEnchant(weapon, "thors_echo") && random.nextDouble() < 0.30) {
            target.getWorld().strikeLightningEffect(target.getLocation());
            for (LivingEntity nearby : target.getLocation().getNearbyLivingEntities(4)) {
                if (nearby != player && nearby != target) {
                    nearby.damage(4.0, player);
                }
            }
        }

        // True Lifesteal: restore 1 HP per hit
        if (em.hasEnchant(weapon, "true_lifesteal")) {
            double maxHp = player.getAttribute(org.bukkit.attribute.Attribute.MAX_HEALTH).getValue();
            player.setHealth(Math.min(maxHp, player.getHealth() + 1));
        }

        // Weak Hunger: 5% chance restore 1 hunger on attack
        if (em.hasEnchant(weapon, "weak_hunger") && random.nextDouble() < 0.05) {
            player.setFoodLevel(Math.min(20, player.getFoodLevel() + 1));
        }

        // Iron Golem Toss: launch enemy up
        if (em.hasEnchant(weapon, "iron_golem_toss")) {
            target.setVelocity(new Vector(
                    (random.nextDouble() - 0.5) * 0.5,
                    1.5,
                    (random.nextDouble() - 0.5) * 0.5
            ));
        }
    }

    @EventHandler
    public void onEntityDeath(EntityDeathEvent event) {
        if (!(event.getEntity().getKiller() instanceof Player player)) return;

        ItemStack weapon = player.getInventory().getItemInMainHand();

        // Vampire: 10% chance restore 5% HP
        if (em.hasEnchant(weapon, "vampire") && random.nextDouble() < 0.10) {
            double maxHp = player.getAttribute(org.bukkit.attribute.Attribute.MAX_HEALTH).getValue();
            double restore = maxHp * 0.05;
            player.setHealth(Math.min(maxHp, player.getHealth() + restore));
            player.spawnParticle(Particle.HEART, player.getLocation().add(0, 1, 0), 5, 0.3, 0.3, 0.3);
        }

        // Refinement: extra XP
        if (em.hasEnchant(weapon, "refinement") && random.nextDouble() < 0.30) {
            int bonus = random.nextInt(3) + 1;
            event.setDroppedExp(event.getDroppedExp() + bonus);
        }

        // Herobrine passive: Soul Drain - full heal on kill
        for (ItemStack armor : player.getInventory().getArmorContents()) {
            if (armor != null && em.hasEnchant(armor, "herobrine")) {
                double maxHp = player.getAttribute(org.bukkit.attribute.Attribute.MAX_HEALTH).getValue();
                player.setHealth(maxHp);
                player.spawnParticle(Particle.SOUL, player.getLocation().add(0, 1, 0), 20, 0.5, 0.5, 0.5, 0.02);
            }
        }
    }

    // ======================== DAMAGE TAKEN ========================

    @EventHandler(priority = EventPriority.HIGH)
    public void onPlayerDamage(EntityDamageEvent event) {
        if (!(event.getEntity() instanceof Player player)) return;

        // Evade: 5% chance to completely avoid damage
        boolean hasEvade = false;
        for (ItemStack armor : player.getInventory().getArmorContents()) {
            if (armor != null && em.hasEnchant(armor, "evade")) { hasEvade = true; break; }
        }
        if (hasEvade && random.nextDouble() < 0.05) {
            event.setCancelled(true);
            player.sendMessage("§e⚡ Evade!");
            player.spawnParticle(Particle.CRIT, player.getLocation().add(0, 1, 0), 10, 0.3, 0.3, 0.3);
            return;
        }

        // Wither Storm passive: Soul Armor (30% less damage)
        for (ItemStack armor : player.getInventory().getArmorContents()) {
            if (armor != null && em.hasEnchant(armor, "wither_storm")) {
                event.setDamage(event.getDamage() * 0.70);
                break;
            }
        }

        // Herobrine passive: Shadow Form (20% dodge)
        for (ItemStack armor : player.getInventory().getArmorContents()) {
            if (armor != null && em.hasEnchant(armor, "herobrine")) {
                if (random.nextDouble() < 0.20) {
                    event.setCancelled(true);
                    player.sendMessage("§0Shadow Form §7— serangan dihindari!");
                    return;
                }
                break;
            }
        }

        // Anti-Explosive: immune to explosions, gain HP
        if (event.getCause() == EntityDamageEvent.DamageCause.BLOCK_EXPLOSION ||
                event.getCause() == EntityDamageEvent.DamageCause.ENTITY_EXPLOSION) {
            ItemStack leggings = player.getInventory().getArmorContents()[1];
            if (leggings != null && em.hasEnchant(leggings, "anti_explosive")) {
                double gain = event.getDamage() * 0.5;
                double maxHp = player.getAttribute(org.bukkit.attribute.Attribute.MAX_HEALTH).getValue();
                player.setHealth(Math.min(maxHp, player.getHealth() + gain));
                event.setCancelled(true);
                player.sendMessage("§6Anti-Explosive §7aktif! Ledakan menyembuhkanmu!");
                return;
            }
        }

        // Fall damage
        if (event.getCause() == EntityDamageEvent.DamageCause.FALL) {
            // Soft Touch: -1 heart
            ItemStack boots = player.getInventory().getArmorContents()[0];
            if (boots != null && em.hasEnchant(boots, "soft_touch")) {
                event.setDamage(Math.max(0, event.getDamage() - 2));
            }

            // Feather Fall: -25%
            if (boots != null && em.hasEnchant(boots, "feather_fall")) {
                event.setDamage(event.getDamage() * 0.75);
            }

            // Auto MLG: if fell from 15+ blocks, cancel damage and place water
            if (boots != null && em.hasEnchant(boots, "auto_mlg")) {
                Double startY = fallStartY.get(player.getUniqueId());
                if (startY != null) {
                    double fallDist = startY - player.getLocation().getY();
                    if (fallDist >= 15) {
                        event.setCancelled(true);
                        Location landLoc = player.getLocation();
                        landLoc.getBlock().setType(Material.WATER);
                        player.sendMessage("§bAuto MLG §7— air muncul!");
                        new BukkitRunnable() {
                            int ticks = 0;
                            @Override
                            public void run() {
                                ticks++;
                                if (ticks >= 20 || !player.isInWater()) {
                                    if (landLoc.getBlock().getType() == Material.WATER) {
                                        landLoc.getBlock().setType(Material.AIR);
                                    }
                                    cancel();
                                }
                            }
                        }.runTaskTimer(plugin, 5L, 5L);
                        fallStartY.remove(player.getUniqueId());
                    }
                }
            }
        }
    }

    @EventHandler(priority = EventPriority.HIGH)
    public void onDamageByEntity(EntityDamageByEntityEvent event) {
        if (!(event.getEntity() instanceof Player player)) return;
        if (!(event.getDamager() instanceof LivingEntity attacker)) return;

        // Molten: burn attacker 3s
        for (ItemStack armor : player.getInventory().getArmorContents()) {
            if (armor != null && em.hasEnchant(armor, "molten")) {
                attacker.setFireTicks(60); // 3 seconds
                break;
            }
        }

        // Gravity Guard: reduce knockback 40%
        boolean hasGravGuard = false;
        for (ItemStack armor : player.getInventory().getArmorContents()) {
            if (armor != null && em.hasEnchant(armor, "gravity_guard")) { hasGravGuard = true; break; }
        }
        if (hasGravGuard) {
            new BukkitRunnable() {
                @Override
                public void run() {
                    Vector v = player.getVelocity();
                    player.setVelocity(v.multiply(0.6));
                }
            }.runTaskLater(plugin, 1L);
        }

        // Life Link: reflect 25% damage back (max 75%)
        for (ItemStack armor : player.getInventory().getArmorContents()) {
            if (armor != null && em.hasEnchant(armor, "life_link")) {
                double reflected = Math.min(event.getDamage() * 0.25, event.getDamage() * 0.75);
                attacker.damage(reflected, player);
                player.sendMessage("§cLife Link §7— " + String.format("%.1f", reflected) + " damage dikembalikan!");
                break;
            }
        }

        // Adrenaline: Speed 3 if HP < 25%
        double maxHp = player.getAttribute(org.bukkit.attribute.Attribute.MAX_HEALTH).getValue();
        if (player.getHealth() / maxHp < 0.25) {
            ItemStack leggings = player.getInventory().getArmorContents()[1];
            if (leggings != null && em.hasEnchant(leggings, "adrenaline")) {
                if (!adrenalineTriggered.contains(player.getUniqueId())) {
                    adrenalineTriggered.add(player.getUniqueId());
                    player.addPotionEffect(new PotionEffect(PotionEffectType.SPEED, 140, 2, true, true));
                    player.sendMessage("§c⚡ Adrenaline §7— Speed III aktif!");
                    new BukkitRunnable() {
                        @Override
                        public void run() { adrenalineTriggered.remove(player.getUniqueId()); }
                    }.runTaskLater(plugin, 200L);
                }
            }
        }

        // Wither Storm passive: Wither Aura (enemies in 3 blocks get Wither)
        for (ItemStack armor : player.getInventory().getArmorContents()) {
            if (armor != null && em.hasEnchant(armor, "wither_storm")) {
                if (attacker instanceof LivingEntity) {
                    attacker.addPotionEffect(new PotionEffect(PotionEffectType.WITHER, 60, 0, true, true));
                }
                break;
            }
        }
    }

    // ======================== DIVINE INTERVENTION ========================

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onPlayerDeath(PlayerDeathEvent event) {
        Player player = event.getEntity();
        ItemStack chestplate = player.getInventory().getArmorContents()[2];

        if (chestplate != null && em.hasEnchant(chestplate, "divine_intervention")) {
            if (!asm.isDICooldown(player)) {
                event.setCancelled(true);
                double maxHp = player.getAttribute(org.bukkit.attribute.Attribute.MAX_HEALTH).getValue();
                player.setHealth(maxHp);
                player.addPotionEffect(new PotionEffect(PotionEffectType.RESISTANCE, 200, 4, true, true));
                player.spawnParticle(Particle.TOTEM_OF_UNDYING, player.getLocation().add(0, 1, 0), 50, 0.5, 0.5, 0.5);
                player.playSound(player.getLocation(), Sound.ITEM_TOTEM_USE, 1f, 1f);
                player.sendMessage("§6§l✦ Divine Intervention ✦ §7— Nyawamu diselamatkan!");
                asm.setDICooldown(player);
            }
        }
    }

    // ======================== BLOCK BREAK EVENTS ========================

    @EventHandler
    public void onBlockBreak(BlockBreakEvent event) {
        Player player = event.getPlayer();
        ItemStack tool = player.getInventory().getItemInMainHand();
        Block block = event.getBlock();

        // Auto-Smelt
        if (em.hasEnchant(tool, "auto_smelt") && ItemUtil.isOre(block.getType())) {
            Material smelted = ItemUtil.getSmeltedResult(block.getType());
            if (smelted != null) {
                event.setDropItems(false);
                player.getWorld().dropItemNaturally(block.getLocation(), new ItemStack(smelted, 1));
                // Also for infinity_miner
            }
        }

        // Infinity Miner: auto smelt all
        if (em.hasEnchant(tool, "infinity_miner") && ItemUtil.isOre(block.getType())) {
            event.setDropItems(false);
            Material smelted = ItemUtil.getSmeltedResult(block.getType());
            Material drop = smelted != null ? smelted : block.getType();
            player.getWorld().dropItemNaturally(block.getLocation(), new ItemStack(drop, 1));
        }

        // Timber: break logs above
        if (em.hasEnchant(tool, "timber") && ItemUtil.isLog(block.getType())) {
            int toBreak = random.nextInt(2) + 2; // 2-3
            Location loc = block.getLocation().clone().add(0, 1, 0);
            for (int i = 0; i < toBreak; i++) {
                Block above = loc.clone().add(0, i, 0).getBlock();
                if (ItemUtil.isLog(above.getType())) {
                    above.breakNaturally(tool);
                }
            }
        }

        // Magnetize: pull nearby drops
        if (em.hasEnchant(tool, "magnetize")) {
            new BukkitRunnable() {
                @Override
                public void run() {
                    for (Item item : player.getWorld().getNearbyEntitiesByType(Item.class, block.getLocation(), 3)) {
                        item.setPickupDelay(0);
                        item.setVelocity(player.getLocation().add(0, 1, 0).subtract(item.getLocation()).toVector().normalize().multiply(0.3));
                    }
                }
            }.runTaskLater(plugin, 2L);
        }

        // Refinement: extra XP from mining
        if (em.hasEnchant(tool, "refinement") && ItemUtil.isOre(block.getType())) {
            int bonus = random.nextInt(3) + 1;
            event.setExpToDrop(event.getExpToDrop() + bonus);
        }

        // Prospector: 5% Haste II for 5s after ore break
        if (em.hasEnchant(tool, "prospector") && ItemUtil.isOre(block.getType())) {
            if (random.nextDouble() < 0.05) {
                player.addPotionEffect(new PotionEffect(PotionEffectType.HASTE, 100, 1, true, true));
                player.sendMessage("§6Prospector §7— Haste II selama 5 detik!");
            }
        }

        // Deep Miner: 10% chance 3x3
        if (em.hasEnchant(tool, "deep_miner") && random.nextDouble() < 0.10) {
            breakAreaBlocks(player, block, 1, tool); // 3x3 = radius 1
        }

        // Super Miner: 3x3x3
        if (em.hasEnchant(tool, "super_miner")) {
            breakAreaBlocks(player, block, 1, tool); // 3x3x3
            breakLayerAboveBelow(player, block, 1, tool);
        }

        // Mega Miner: 5x5x5
        if (em.hasEnchant(tool, "mega_miner")) {
            breakAreaBlocks(player, block, 2, tool);
            breakLayerAboveBelow(player, block, 2, tool);
        }

        // Infinity Miner: 7x7x7
        if (em.hasEnchant(tool, "infinity_miner")) {
            breakAreaBlocks(player, block, 3, tool);
            breakLayerAboveBelow(player, block, 3, tool);
        }
    }

    private void breakAreaBlocks(Player player, Block center, int radius, ItemStack tool) {
        for (int x = -radius; x <= radius; x++) {
            for (int z = -radius; z <= radius; z++) {
                if (x == 0 && z == 0) continue;
                Block b = center.getRelative(x, 0, z);
                if (b.getType() != Material.AIR && b.getType() != Material.BEDROCK) {
                    b.breakNaturally(tool);
                }
            }
        }
    }

    private void breakLayerAboveBelow(Player player, Block center, int radius, ItemStack tool) {
        for (int y = -radius; y <= radius; y++) {
            if (y == 0) continue;
            for (int x = -radius; x <= radius; x++) {
                for (int z = -radius; z <= radius; z++) {
                    Block b = center.getRelative(x, y, z);
                    if (b.getType() != Material.AIR && b.getType() != Material.BEDROCK) {
                        b.breakNaturally(tool);
                    }
                }
            }
        }
    }

    // ======================== FISHING ========================

    @EventHandler
    public void onFish(PlayerFishEvent event) {
        if (event.getState() != PlayerFishEvent.State.CAUGHT_FISH) return;
        Player player = event.getPlayer();
        ItemStack rod = player.getInventory().getItemInMainHand();
        if (!em.hasEnchant(rod, "fishermans_luck")) return;

        if (random.nextDouble() < 0.10) {
            // Give extra fish
            if (event.getCaught() instanceof Item caughtItem) {
                ItemStack extra = caughtItem.getItemStack().clone();
                extra.setAmount(1);
                player.getWorld().dropItemNaturally(player.getLocation(), extra);
                player.sendMessage("§aFisherman's Luck §7— Dapat 2 ikan sekaligus!");
            }
        }
    }

    // ======================== ITEM DAMAGE (STURDY) ========================

    @EventHandler
    public void onItemDamage(PlayerItemDamageEvent event) {
        Player player = event.getPlayer();
        ItemStack item = event.getItem();
        if (em.hasEnchant(item, "sturdy") && random.nextDouble() < 0.05) {
            event.setCancelled(true);
        }
    }

    // ======================== FARMER'S GRACE ========================

    @EventHandler
    public void onBlockBreakFarm(BlockBreakEvent event) {
        Player player = event.getPlayer();
        ItemStack tool = player.getInventory().getItemInMainHand();
        if (!em.hasEnchant(tool, "farmers_grace")) return;

        Block block = event.getBlock();
        if (!ItemUtil.isCrop(block.getType())) return;

        // Check if fully grown
        if (block.getBlockData() instanceof Ageable crop) {
            if (crop.getAge() < crop.getMaximumAge()) return;

            // Auto replant
            Material seedType = getSeedType(block.getType());
            if (seedType != null && player.getInventory().contains(seedType)) {
                new BukkitRunnable() {
                    @Override
                    public void run() {
                        if (block.getType() == Material.AIR || block.getType() == block.getType()) {
                            // Try to place seed
                            Block farmland = block.getRelative(BlockFace.DOWN);
                            if (farmland.getType() == Material.FARMLAND) {
                                block.setType(block.getType()); // Will be air but try replant
                                // Actually replant
                                Material cropType = block.getType();
                                // Check if block is still air after break
                            }
                        }
                    }
                }.runTaskLater(plugin, 1L);

                // Remove one seed from inventory
                player.getInventory().removeItem(new ItemStack(seedType, 1));
                new BukkitRunnable() {
                    @Override
                    public void run() {
                        if (block.getType() == Material.AIR) {
                            Block farmland = block.getRelative(BlockFace.DOWN);
                            if (farmland.getType() == Material.FARMLAND) {
                                block.setType(getCropType(seedType));
                            }
                        }
                    }
                }.runTaskLater(plugin, 2L);
            }
        }
    }

    // ======================== CRUSHING (MACE) ========================

    @EventHandler
    public void onCrushingAttack(EntityDamageByEntityEvent event) {
        if (!(event.getDamager() instanceof Player player)) return;
        if (!(event.getEntity() instanceof LivingEntity target)) return;

        ItemStack weapon = player.getInventory().getItemInMainHand();
        if (!em.hasEnchant(weapon, "crushing")) return;

        // Get fall velocity approximation
        Double startY = fallStartY.get(player.getUniqueId());
        if (startY == null) return;

        double fallDist = startY - player.getLocation().getY();
        if (fallDist < 3) return;

        // Stun = slowness + mining fatigue based on fall distance
        int stunTicks = (int) (fallDist * 5); // 5 ticks per block fallen
        stunTicks = Math.min(stunTicks, 200); // max 10 seconds
        target.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS, stunTicks, 5));
        target.addPotionEffect(new PotionEffect(PotionEffectType.MINING_FATIGUE, stunTicks, 5));
        if (target instanceof Player tp) {
            tp.addPotionEffect(new PotionEffect(PotionEffectType.BLINDNESS, stunTicks, 0));
        }
        player.sendMessage("§aCrushing! §7Musuh terstun selama " + String.format("%.1f", stunTicks / 20.0) + " detik!");
    }

    // ======================== HEALTH BOOST ========================

    @EventHandler
    public void onArmorEquip(PlayerItemHeldEvent event) {
        // Re-check health boost on item change
        new BukkitRunnable() {
            @Override
            public void run() { tickHeartOfTitan(event.getPlayer()); }
        }.runTaskLater(plugin, 1L);
    }


    // ======================== SECRET / SPECIAL PASSIVE TICK ========================

    public void setProjectileListener(com.eternalcraft.enchantexpansion.listener.ProjectileEnchantListener pl) {
        this.projListener = pl;
    }

    private final Map<UUID, Integer> secretBossHP = new HashMap<>();

    private void tickSecretSpecialPassives(Player player) {
        ItemStack chestplate = player.getInventory().getArmorContents()[2];
        if (chestplate == null) return;

        boolean hasWitherStorm = em.hasEnchant(chestplate, "wither_storm");
        boolean hasHerobrine  = em.hasEnchant(chestplate, "herobrine");
        boolean hasDemonic    = em.hasEnchant(chestplate, "demonic_takaz");

        // Boss Health: +20 HP for secret enchants
        if (hasWitherStorm || hasHerobrine) {
            applyBossHealth(player, 20);
        }

        // Wither Storm passives
        if (hasWitherStorm && projListener != null) {
            projListener.tickWitherStormPassive(player);
            // Soul Armor — 35% damage reduction handled in onDamage
        }

        // Herobrine passives
        if (hasHerobrine && projListener != null) {
            projListener.tickHerobrinePassive(player);
        }

        // Demonic Takaz aura
        if (hasDemonic && projListener != null) {
            projListener.tickDemonicTakazAura(player);
        }
    }

    private void applyBossHealth(Player player, int extraHP) {
        int current = secretBossHP.getOrDefault(player.getUniqueId(), 0);
        if (current != extraHP) {
            var attr = player.getAttribute(org.bukkit.attribute.Attribute.MAX_HEALTH);
            if (attr != null) {
                attr.setBaseValue(20.0 + extraHP);
            }
            secretBossHP.put(player.getUniqueId(), extraHP);
        }
    }

    // ======================== HELPERS ========================

    private boolean isZombie(Entity e) {
        return e instanceof Zombie || e instanceof Husk || e instanceof ZombieVillager || e instanceof DrownedFish;
    }

    private boolean isSkeleton(Entity e) {
        return e instanceof Skeleton || e instanceof Stray || e instanceof Bogged;
    }

    private boolean isWitherMob(Entity e) {
        return e instanceof WitherSkeleton || e instanceof Wither;
    }

    private boolean isEnderMob(Entity e) {
        return e instanceof Enderman || e instanceof Shulker;
    }

    private Material getSeedType(Material crop) {
        return switch (crop) {
            case WHEAT -> Material.WHEAT_SEEDS;
            case CARROTS -> Material.CARROT;
            case POTATOES -> Material.POTATO;
            case BEETROOTS -> Material.BEETROOT_SEEDS;
            case NETHER_WART -> Material.NETHER_WART;
            default -> null;
        };
    }

    private Material getCropType(Material seed) {
        return switch (seed) {
            case WHEAT_SEEDS -> Material.WHEAT;
            case CARROT -> Material.CARROTS;
            case POTATO -> Material.POTATOES;
            case BEETROOT_SEEDS -> Material.BEETROOTS;
            case NETHER_WART -> Material.NETHER_WART;
            default -> Material.AIR;
        };
    }
}
