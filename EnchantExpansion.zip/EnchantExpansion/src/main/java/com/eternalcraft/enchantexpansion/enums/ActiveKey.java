package com.eternalcraft.enchantexpansion.enums;

public enum ActiveKey {
    SNEAK_CLICK("Sneak + Klik Kanan"),
    CLICK("Klik Kanan"),
    HOLD("Tahan Klik Kanan"),
    SNEAK_HOLD("Sneak + Tahan Klik Kanan"),
    RUN_CLICK("Lari + Klik Kanan"),
    SNEAK_JUMP("Sneak + Lompat"),
    NONE("Pasif");

    private final String displayName;

    ActiveKey(String displayName) {
        this.displayName = displayName;
    }

    public String getDisplayName() {
        return displayName;
    }
}
